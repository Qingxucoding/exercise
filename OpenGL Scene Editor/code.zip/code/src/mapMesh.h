#ifndef MAPMESH_H
#define MAPMESH_H

#include <vector>
#include <memory>
#include <string>
#include "stb_image.h"
#include "glm/glm.hpp"
#include <iostream>
#include "TRShadingState.h"
#include "TRDrawableMesh.h"
#include <cstring>
#include "glm/gtc/matrix_transform.hpp"

namespace TinyRenderer
{
	class MapMesh : public TRDrawableMesh
	{
	public:
		typedef std::shared_ptr<MapMesh> ptr;

		std::vector<float> m_map_data;
		int imgWidth, imgHeight;
		glm::vec4 m_center_pos = glm::vec4(0.0f);

		MapMesh(const std::string& mapPath) : imgWidth(1280), imgHeight(1058) {

			int channels;
			unsigned char* data = stbi_load(mapPath.c_str(), &imgWidth, &imgHeight, &channels, 0);
			if (!data) {
				std::cerr << "Failed to load image: " << mapPath << std::endl;
				return;
			}
            m_map_data.resize(imgWidth * imgHeight);
			
			for (int i = 0; i < imgHeight * imgWidth * channels; i += channels) {
				for (int j = 0; j < channels; j++) {
                    m_map_data[i / channels] += float(unsigned int(data[i + j])) / channels;
				}
			}
			stbi_image_free(data);
			std::cout << channels << std::endl;
			for (int i = 0; i < imgWidth * imgHeight; i++) {
				glm::vec4 pos = this->get_model_pos(i % imgWidth, i / imgWidth);
				m_vertices_attrib.vpositions.push_back(pos);
				m_vertices_attrib.vcolors.push_back(glm::vec4(255.0f, pos.y, 255.0f, 1.0f));
			}
			m_vertices_attrib.vtexcoords.push_back(glm::vec2(0.0f, 0.0f));
			for (int i = 1; i < imgHeight; ++i) {
                for (int j = 1; j < imgWidth; ++j) {
					for (int kk = 0; kk < 2; ++kk) {
						TRMeshFace face;
						int height = read_map(j, i);
						face.vposIndex[0] = j + i * imgWidth;
						face.vposIndex[1] = j + (i - 1) * imgWidth;
						face.vposIndex[2] = j - 1 + (i - 1) * imgWidth;
						if (kk == 1) {
							face.vposIndex[1] = j -1 + (i- 1) * imgWidth;
                            face.vposIndex[2] = j - 1+ i * imgWidth;
						}
						face.vtexIndex[0] = face.vtexIndex[1] = face.vtexIndex[2] = 0;

						glm::vec4 v1 = m_vertices_attrib.vpositions[face.vposIndex[1]] - m_vertices_attrib.vpositions[face.vposIndex[0]];
						glm::vec4 v2 = m_vertices_attrib.vpositions[face.vposIndex[2]] - m_vertices_attrib.vpositions[face.vposIndex[0]];
						face.vnorIndex[0] = face.vnorIndex[1] = face.vnorIndex[2] = m_vertices_attrib.vnormals.size();
						m_vertices_attrib.vnormals.push_back(glm::normalize(glm::cross(glm::vec3(v1), glm::vec3(v2))));
	

						//Material
						{
							face.kA = glm::vec3(0.1f, 0.1f, 0.1f);
							face.kD = glm::vec3(0.01f, 0.01f, 0.01f);
							face.kS = glm::vec3(0.05f, 0.05f, 0.05f);
							face.kE = glm::vec3(float(height % 13 / 13.0f), float(height % 7 / 7.0f), float(height % 11 / 11.0f));
							//face.shininess = 2.0f;
							//face.diffuseMapTexId = 0;
							//face.specularMapTexId = 0;
							//face.normalMapTexId = 0;
							//face.glowMapTexId = 0;
						}


						{

							glm::vec3 edge1 = glm::vec3(m_vertices_attrib.vpositions[face.vposIndex[1]])
								- glm::vec3(m_vertices_attrib.vpositions[face.vposIndex[0]]);
							glm::vec3 edge2 = glm::vec3(m_vertices_attrib.vpositions[face.vposIndex[2]])
								- glm::vec3(m_vertices_attrib.vpositions[face.vposIndex[0]]);

							glm::vec2 deltaUV1 = glm::vec2(m_vertices_attrib.vtexcoords[face.vtexIndex[1]])
								- glm::vec2(m_vertices_attrib.vtexcoords[face.vtexIndex[0]]);
							glm::vec2 deltaUV2 = glm::vec2(m_vertices_attrib.vtexcoords[face.vtexIndex[2]])
								- glm::vec2(m_vertices_attrib.vtexcoords[face.vtexIndex[0]]);

							float f = 1.0f / (deltaUV1.x * deltaUV2.y - deltaUV2.x * deltaUV1.y);

							glm::vec3 tangent;
							tangent.x = f * (deltaUV2.y * edge1.x - deltaUV1.y * edge2.x);
							tangent.y = f * (deltaUV2.y * edge1.y - deltaUV1.y * edge2.y);
							tangent.z = f * (deltaUV2.y * edge1.z - deltaUV1.y * edge2.z);

							glm::vec3 bitangent;
							bitangent.x = f * (-deltaUV2.x * edge1.x + deltaUV1.x * edge2.x);
							bitangent.y = f * (-deltaUV2.x * edge1.y + deltaUV1.x * edge2.y);
							bitangent.z = f * (-deltaUV2.x * edge1.z + deltaUV1.x * edge2.z);

							face.tangent = glm::normalize(tangent);
							face.bitangent = glm::normalize(bitangent);
						}

						m_mesh_faces.push_back(face);
					}



				}

			}

			m_center_pos = this->get_model_pos(imgWidth / 2, imgHeight / 2);

			//��ʼ�任����,1.0��ʾ����������任
			glm::mat4 map_mesh_model_mat = glm::mat4(1.0f);
			//���ŵ��ξ���
			map_mesh_model_mat = glm::scale(map_mesh_model_mat, glm::vec3(1.0f, 0.1f, 1.0f));
			//ƽ�ƾ���
			glm::vec4 target_pos = glm::vec4(0.0f, 0.0f, 0.0f, 1.0f);
			glm::vec4 now_pos = this->m_center_pos;
			glm::mat4 map_move_mat = glm::translate(glm::mat4(1.0f), glm::vec3(target_pos - now_pos));
			//Ӧ�ñ任
			map_mesh_model_mat = map_mesh_model_mat * map_move_mat;
			this->setModelMatrix(map_mesh_model_mat);
		}

		MapMesh(const std::string& mapPath, const std::string& imagePath) {
			int channels;
			unsigned char* data = stbi_load(mapPath.c_str(), &imgWidth, &imgHeight, &channels, 0);
			if (!data) {
				std::cerr << "Failed to load image: " << mapPath << std::endl;
				return;
			}
			m_map_data.resize(imgWidth * imgHeight);

			for (int i = 0; i < imgHeight * imgWidth * channels; i += channels) {
				for (int j = 0; j < channels; j++) {
					m_map_data[i / channels] += float(unsigned int(data[i + j])) / channels;
				}
			}
			stbi_image_free(data);
			std::cout << channels << std::endl;
			std::cout << "mapMesh" << this->imgHeight << this->imgWidth << std::endl;
			for (int i = 0; i < imgHeight * imgWidth; i++) {
				m_map_data[i] = int(abs(m_map_data[i])) % 2 + 1;
			}
			TRTexture2D::ptr Tex = std::make_shared<TRTexture2D>();
			bool success = Tex->loadTextureFromFile(imagePath);
			int texid = TRShadingPipeline::upload_texture_2D(Tex);
			if (!success) {
                std::cout << "Error loading texture" << std::endl;
			}

			m_vertices_attrib.vnormals.push_back(glm::vec3(1.0f, 0.0f, 0.0f));
			m_vertices_attrib.vnormals.push_back(glm::vec3(0.0f, 1.0f, 0.0f));
			m_vertices_attrib.vnormals.push_back(glm::vec3(0.0f, 0.0f, 1.0f));
			m_vertices_attrib.vnormals.push_back(glm::vec3(-1.0f, 0.0f, 0.0f));
            m_vertices_attrib.vnormals.push_back(glm::vec3(0.0f, -1.0f, 0.0f));
            m_vertices_attrib.vnormals.push_back(glm::vec3(0.0f, 0.0f, -1.0f));

			m_vertices_attrib.vtexcoords.push_back(glm::vec2(0.0f, 0.0f));
			m_vertices_attrib.vtexcoords.push_back(glm::vec2(1.0f, 0.0f));
			m_vertices_attrib.vtexcoords.push_back(glm::vec2(0.0f, 1.0f));
			m_vertices_attrib.vtexcoords.push_back(glm::vec2(1.0f, 1.0f));
			for (int i = 0; i < imgHeight * imgWidth; ++i) {
				int height = int(m_map_data[i]);
				for (int h = 0; h < height; ++h) {
					int x = i % imgWidth, y = h, z = i / imgWidth;
					m_vertices_attrib.vpositions.push_back(glm::vec4(x, y, z, 1.0f));
					m_vertices_attrib.vpositions.push_back(glm::vec4(x + 1, y, z, 1.0f));
                    m_vertices_attrib.vpositions.push_back(glm::vec4(x + 1, y, z + 1, 1.0f));
                    m_vertices_attrib.vpositions.push_back(glm::vec4(x, y, z + 1, 1.0f));
					m_vertices_attrib.vpositions.push_back(glm::vec4(x, y + 1, z, 1.0f));
                    m_vertices_attrib.vpositions.push_back(glm::vec4(x + 1, y + 1, z, 1.0f));
                    m_vertices_attrib.vpositions.push_back(glm::vec4(x + 1, y + 1, z + 1, 1.0f));
                    m_vertices_attrib.vpositions.push_back(glm::vec4(x, y + 1, z + 1, 1.0f));

					for (int mm =0; mm < 8 ; ++mm)
					m_vertices_attrib.vcolors.push_back(glm::vec4(255.0f, 255.0f, 255.0f, 1.0f));

					for (int kk = 0; kk < 12; ++kk) {
						TRMeshFace face;
						face.vposIndex[2] = 8 * i + 2; face.vnorIndex[0] = face.vnorIndex[1] = face.vnorIndex[2] = kk / 2;
						switch(kk)
						{
						case 0: face.vposIndex[0] = 8 * i + 0; face.vposIndex[1] = 8 * i + 3; face.vposIndex[2] = 8 * i + 7; break;
						case 1: face.vposIndex[0] = 8 * i + 0; face.vposIndex[1] = 8 * i + 7; face.vposIndex[2] = 8 * i + 4; break;

						case 2: face.vposIndex[0] = 8 * i + 5; face.vposIndex[1] = 8 * i + 4; face.vposIndex[2] = 8 * i + 7; break;
						case 3: face.vposIndex[0] = 8 * i + 5; face.vposIndex[1] = 8 * i + 7; face.vposIndex[2] = 8 * i + 6; break;

						case 4: face.vposIndex[0] = 8 * i + 1; face.vposIndex[1] = 8 * i + 0; face.vposIndex[2] = 8 * i + 4; break;
						case 5: face.vposIndex[0] = 8 * i + 1; face.vposIndex[1] = 8 * i + 4; face.vposIndex[2] = 8 * i + 5; break;

						case 6: face.vposIndex[0] = 8 * i + 2; face.vposIndex[1] = 8 * i + 1; face.vposIndex[2] = 8 * i + 5; break;
						case 7: face.vposIndex[0] = 8 * i + 2; face.vposIndex[1] = 8 * i + 5; face.vposIndex[2] = 8 * i + 6; break;

						case 8: face.vposIndex[0] = 8 * i + 2; face.vposIndex[1] = 8 * i + 3; face.vposIndex[2] = 8 * i + 0; break;
						case 9: face.vposIndex[0] = 8 * i + 2; face.vposIndex[1] = 8 * i + 0; face.vposIndex[2] = 8 * i + 1; break;

						case 10: face.vposIndex[0] = 8 * i + 3; face.vposIndex[1] = 8 * i + 2; face.vposIndex[2] = 8 * i + 6; break;
						case 11: face.vposIndex[0] = 8 * i + 3; face.vposIndex[1] = 8 * i + 6; face.vposIndex[2] = 8 * i + 7; break;
						}

						if (kk % 2 == 0) {
							face.vtexIndex[0] = 1;
							face.vtexIndex[1] = 0;
							face.vtexIndex[2] = 2;
						}
						else {
                            face.vtexIndex[0] = 1;
							face.vtexIndex[1] = 2;
							face.vtexIndex[2] = 3;
						}
						

						glm::vec4 v1 = m_vertices_attrib.vpositions[face.vposIndex[1]] - m_vertices_attrib.vpositions[face.vposIndex[0]];
						glm::vec4 v2 = m_vertices_attrib.vpositions[face.vposIndex[2]] - m_vertices_attrib.vpositions[face.vposIndex[0]];


						//Material
						{
							face.kA = glm::vec3(0.1f, 0.1f, 0.1f);
							face.kD = glm::vec3(0.1f, 0.1f, 0.1f);
							face.kS = glm::vec3(0.1f, 0.1f, 0.1f);
							face.kE = glm::vec3(0.1f, 0.1f, 0.1f);
							face.shininess = 1.0f;
							face.diffuseMapTexId = texid;
							face.specularMapTexId = texid;
							face.normalMapTexId = texid;
							face.glowMapTexId = texid;
						}


						{

							glm::vec3 edge1 = glm::vec3(m_vertices_attrib.vpositions[face.vposIndex[1]])
								- glm::vec3(m_vertices_attrib.vpositions[face.vposIndex[0]]);
							glm::vec3 edge2 = glm::vec3(m_vertices_attrib.vpositions[face.vposIndex[2]])
								- glm::vec3(m_vertices_attrib.vpositions[face.vposIndex[0]]);

							glm::vec2 deltaUV1 = glm::vec2(m_vertices_attrib.vtexcoords[face.vtexIndex[1]])
								- glm::vec2(m_vertices_attrib.vtexcoords[face.vtexIndex[0]]);
							glm::vec2 deltaUV2 = glm::vec2(m_vertices_attrib.vtexcoords[face.vtexIndex[2]])
								- glm::vec2(m_vertices_attrib.vtexcoords[face.vtexIndex[0]]);

							float f = 1.0f / (deltaUV1.x * deltaUV2.y - deltaUV2.x * deltaUV1.y);

							glm::vec3 tangent;
							tangent.x = f * (deltaUV2.y * edge1.x - deltaUV1.y * edge2.x);
							tangent.y = f * (deltaUV2.y * edge1.y - deltaUV1.y * edge2.y);
							tangent.z = f * (deltaUV2.y * edge1.z - deltaUV1.y * edge2.z);

							glm::vec3 bitangent;
							bitangent.x = f * (-deltaUV2.x * edge1.x + deltaUV1.x * edge2.x);
							bitangent.y = f * (-deltaUV2.x * edge1.y + deltaUV1.x * edge2.y);
							bitangent.z = f * (-deltaUV2.x * edge1.z + deltaUV1.x * edge2.z);

							face.tangent = glm::normalize(tangent);
							face.bitangent = glm::normalize(bitangent);
						}

						m_mesh_faces.push_back(face);
					}
				}
			}

			m_center_pos = this->get_model_pos(imgWidth / 2, imgHeight / 2);
			//��ʼ�任����,1.0��ʾ����������任
			glm::mat4 map_mesh_model_mat = glm::mat4(1.0f);
			//���ŵ��ξ���
			map_mesh_model_mat = glm::scale(map_mesh_model_mat, glm::vec3(1.0f, 1.0f, 1.0f));
			//ƽ�ƾ���
			glm::vec4 target_pos = glm::vec4(0.0f, 0.0f, 0.0f, 1.0f);
			glm::vec4 now_pos = this->m_center_pos;
			glm::mat4 map_move_mat = glm::translate(glm::mat4(1.0f), glm::vec3(target_pos - now_pos));
			//Ӧ�ñ任
			map_mesh_model_mat = map_mesh_model_mat * map_move_mat;
			this->setModelMatrix(map_mesh_model_mat);
		};

		float read_map(int x, int z) {
			if (x > (this->imgWidth - 1) || z > (imgHeight - 1) || x < 0 || z < 0) {
				//std::cout << "MapMesh: out of range"<< x<< " "<< z << std::endl;
				return -100.f;
			}
			float y = this->m_map_data[z * this->imgWidth + x];
            //std::cout << "MapMesh: " << y << std::endl;
            return y;
		}

		glm::vec4 get_model_pos(int x, int z) {
			float y = this->m_map_data[z * imgWidth + x];
			return glm::vec4(x, y, z, 1.0f);
		}

		glm::vec4 get_index(glm::vec4 pos) {
			float y = read_map(pos.x, pos.z);
            return glm::vec4(pos.x, y, pos.z, 1.0f);
		}
	};
};

#endif