#include "TRRenderer.h"
#include<memory>
#include "glm/gtc/matrix_transform.hpp"
#include<iostream>
#include "TRShadingPipeline.h"
#include "TRUtils.h"
#include <cmath>
#include "mapMesh.h"
void print_vec4(const glm::vec4& v) {
    std::cout << "(" << v.x << ", " << v.y << ", " << v.z << ", " << v.w << ")" << std::endl;
}

namespace TinyRenderer
{

	TRRenderer::TRRenderer(int width, int height)
		: m_backBuffer(nullptr), m_frontBuffer(nullptr)
	{
		//Double buffer to avoid flickering
		m_backBuffer = std::make_shared<TRFrameBuffer>(width, height);
		m_frontBuffer = std::make_shared<TRFrameBuffer>(width, height);

		//Setup viewport matrix (ndc space -> screen space)
		m_viewportMatrix = TRUtils::calcViewPortMatrix(width, height);

		// my change
		clicked_model_index = -1;
		clicked_point_x = -1;
		clicked_point_z = -1;
	}

	void TRRenderer::addDrawableMesh(TRDrawableMesh::ptr mesh)
	{
		m_drawableMeshes.push_back(mesh);
		const auto& vertices = m_drawableMeshes.back()->getVerticesAttrib();
		const auto& faces = m_drawableMeshes.back()->getMeshFaces();
		float max_x = vertices.vpositions[faces[0].vposIndex[0]].x;
		float min_x = vertices.vpositions[faces[0].vposIndex[0]].x;
		float max_y = vertices.vpositions[faces[0].vposIndex[0]].y;
		float min_y = vertices.vpositions[faces[0].vposIndex[0]].y;
		float max_z = vertices.vpositions[faces[0].vposIndex[0]].z;
		float min_z = vertices.vpositions[faces[0].vposIndex[0]].z;

		glm::vec4 feet_mpos = vertices.vpositions[0];
		for (size_t f = 0; f < faces.size(); ++f) {
			glm::vec3 one_dot_in_face = vertices.vpositions[faces[f].vposIndex[0]];
			max_x = one_dot_in_face.x > max_x ? one_dot_in_face.x : max_x;
			min_x = one_dot_in_face.x < min_x ? one_dot_in_face.x : min_x;
			max_y = one_dot_in_face.y > max_y ? one_dot_in_face.y : max_y;
			min_y = one_dot_in_face.y < min_y ? one_dot_in_face.y : min_y;
            max_z = one_dot_in_face.z > max_z ? one_dot_in_face.z : max_z;
            min_z = one_dot_in_face.z < min_z ? one_dot_in_face.z : min_z;
			if (one_dot_in_face.y < feet_mpos.y) {
				feet_mpos = glm::vec4(one_dot_in_face, 1.0f);
			}
		}
		mesh->feet_mpos = feet_mpos;
		glm::vec4 max_point = glm::vec4(max_x, max_y, max_z, 1.0f);
        glm::vec4 min_point = glm::vec4(min_x, min_y, min_z, 1.0f);
		max_point = max_point;
		min_point = min_point;
        this->easyModels.push_back(std::make_shared<easyModel>(min_point, max_point));
		std::cout << "Added a mesh with " << faces.size() << " faces." << std::endl;
	}

	void TRRenderer::addDrawableMesh(const std::vector<TRDrawableMesh::ptr>& meshes)
	{
		//m_drawableMeshes.insert(m_drawableMeshes.end(), meshes.begin(), meshes.end());
		for (int m = 0;m < meshes.size(); ++m) {
			auto mesh = meshes[m];
			this->addDrawableMesh(mesh);
		}
	}

	// my change 
	void TRRenderer::clickEasyModel(int mouse_x, int mouse_y, bool is_click) {
		if (!is_click) {
			this->clicked_model_index = -1;
			return;
		}
		if (this->clicked_model_index != -1)return;
		glm::mat4 buf = glm::mat4(m_viewportMatrix);
		buf[3][3] = 1.0f;
		buf = glm::inverse(buf);
		glm::vec4 far_pos = buf * glm::vec4(mouse_x, mouse_y, 1.0f, 1.0f);
		far_pos[3, 3] = 1.0f;
		far_pos = 100.0f * far_pos;
		glm::vec4 near_pos = buf * glm::vec4(mouse_x, mouse_y, -1.0f, 1.0f);
		near_pos[3, 3] = 1.0f;
		near_pos = 0.001f * near_pos;
		near_pos = glm::inverse(m_viewMatrix) * glm::inverse(m_projectMatrix) * near_pos;
		far_pos = glm::inverse(m_viewMatrix) * glm::inverse(m_projectMatrix) * far_pos;
		glm::vec4 ray_dir = glm::normalize(far_pos - near_pos); ray_dir[3] = 0.0f;
		glm::vec4 ray_pos = glm::vec4(near_pos); ray_pos[3] = 1.0f;
		glm::vec4 last_ray_pos = glm::vec4(near_pos); last_ray_pos[3] = 1.0f;
		float unit_length = glm::length(near_pos - far_pos) / 30.0f;
		for (int i = 0; i < 30; i++) {
			ray_pos += unit_length * ray_dir;
			for (int j = 0; j < this->easyModels.size(); j++) {
				if (j == this->roleMesh_index || j == this->mapMesh_index || j == this->skyMesh_index) continue;
				if (this->easyModels[j]->in_and_out(ray_pos, last_ray_pos, this->m_drawableMeshes[j]->getModelMatrix())) {
					std::cout << "congratulaton!!!" << i << " " << j << std::endl;
					this->clicked_model_index = j;
					return;
				}
			}
			last_ray_pos += unit_length * ray_dir;
		}
	}
	glm::vec4 TRRenderer::clickMapPoint(int mouse_x, int mouse_y, bool is_click) {
		if (!is_click) {
			this->clicked_point_x = -1;
			this->clicked_point_z = -1;
			return glm::vec4(0.0f);
		}
		//if (this->clicked_model_index != -1) return;
		glm::mat4 buf = glm::mat4(m_viewportMatrix);
		buf[3][3] = 1.0f;
		buf = glm::inverse(buf);
		glm::vec4 far_pos = buf * glm::vec4(mouse_x, mouse_y, 1.0f, 1.0f);
		far_pos[3, 3] = 1.0f;
		far_pos = 100.0f * far_pos;
		glm::vec4 near_pos = buf * glm::vec4(mouse_x, mouse_y, -1.0f, 1.0f);
		near_pos[3, 3] = 1.0f;
		near_pos = 0.001f * near_pos;
		near_pos = glm::inverse(m_viewMatrix) * glm::inverse(m_projectMatrix) * near_pos;
		far_pos = glm::inverse(m_viewMatrix) * glm::inverse(m_projectMatrix) * far_pos;
		glm::vec4 ray_dir = glm::normalize(far_pos - near_pos); ray_dir[3] = 0.0f;
		glm::vec4 ray_pos = glm::vec4(near_pos); ray_pos[3] = 1.0f;
		glm::vec4 last_ray_pos = glm::vec4(near_pos); last_ray_pos[3] = 1.0f;
		float unit_length = glm::length(near_pos - far_pos) / 30.0f;
		bool is_in_map = false;
		std::shared_ptr<MapMesh> childPtr = this->m_map_mesh;
		for (int i = 0; i < 30; i++) {
			ray_pos += unit_length * ray_dir;
			float map_y = (childPtr->getModelMatrix() * childPtr->get_index(glm::inverse(childPtr->getModelMatrix()) * ray_pos)).y;
			if (ray_pos.y < map_y) {
				is_in_map = true;
				print_vec4(ray_pos);
				print_vec4(last_ray_pos);
				print_vec4(childPtr->getModelMatrix() * childPtr->get_index(glm::inverse(childPtr->getModelMatrix()) * ray_pos));
				std::cout<< i <<std::endl;
				break;
			}
			last_ray_pos += unit_length * ray_dir;
		}
		if (!is_in_map) {
			std::cout << "not in map" << std::endl;
			return glm::vec4(0.0f);
		}
		// binary search
		glm::vec4 up_ray_pos = glm::vec4(last_ray_pos);
		glm::vec4 down_ray_pos = glm::vec4(ray_pos);
		while (true) {
			glm::vec4 mid_ray_pos = (up_ray_pos + down_ray_pos) / 2.0f;
			float map_y = (childPtr->getModelMatrix() * childPtr->get_index(glm::inverse(childPtr->getModelMatrix()) * ray_pos)).y;
			if (mid_ray_pos.y < map_y) {
				down_ray_pos = mid_ray_pos;
			}
			else {
				up_ray_pos = mid_ray_pos;
			}
			print_vec4(up_ray_pos);
			print_vec4(down_ray_pos);
			print_vec4(childPtr->getModelMatrix() * childPtr->get_index(glm::inverse(childPtr->getModelMatrix()) * ray_pos));
			if (glm::length(up_ray_pos - down_ray_pos) < 0.01f) {
				std::cout << "congratuation!!!" << std::endl;
				return up_ray_pos;
			}
		}
	}
	void TRRenderer::addMapMesh(MapMesh::ptr mesh)
	{
		this->mapMesh_index = m_drawableMeshes.size();
        this->m_map_mesh = mesh;
		this->addDrawableMesh(mesh);
	}

	void TRRenderer::addRoleMesh(TRDrawableMesh::ptr mesh)
	{
		this->roleMesh_index = m_drawableMeshes.size();
		this->m_role_mesh = mesh;
		this->addDrawableMesh(mesh);
	}

	void TRRenderer::addSkyMesh(SkyMesh::ptr mesh) {
        this->m_sky_mesh = mesh;
		this->skyMesh_index = m_drawableMeshes.size();
		this->addDrawableMesh(mesh);
	}

	void TRRenderer::setViewMatrix(glm::vec3 camera, glm::vec3 target, glm::vec3 worldUp) {
		m_mvp_dirty = true;
        m_viewMatrix = TRUtils::calcViewMatrix(camera, target, worldUp);
		m_skyviewMatrix = TRUtils::calcViewMatrix(glm::vec3(0.0f), glm::normalize(target - camera), worldUp);
	}

	void TRRenderer::unloadDrawableMesh()
	{
		for (size_t i = 0; i < m_drawableMeshes.size(); ++i)
		{
			m_drawableMeshes[i]->clear();
		}
		std::vector<TRDrawableMesh::ptr>().swap(m_drawableMeshes);
	}



	//void TRRenderer::setViewMatrix(const glm::mat4 &view)
	//{
	//	m_mvp_dirty = true;
	//	m_viewMatrix = view;
	//}

	void TRRenderer::setModelMatrix(const glm::mat4 &model)
	{
		m_mvp_dirty = true;
		m_modelMatrix = model;
	}

	void TRRenderer::setProjectMatrix(const glm::mat4 &project, float near, float far)
	{
		m_mvp_dirty = true;
		m_projectMatrix = project;
		m_frustum_near_far = glm::vec2(near, far);
	}

	void TRRenderer::setShaderPipeline(TRShadingPipeline::ptr shader)
	{
		m_shader_handler = shader;
	}

	void TRRenderer::setViewerPos(const glm::vec3 &viewer)
	{
		if (m_shader_handler == nullptr)
			return;
		m_shader_handler->setViewerPos(viewer);
	}

	glm::mat4 TRRenderer::getMVPMatrix()
	{
		if (m_mvp_dirty)
		{
			m_mvp_matrix = m_projectMatrix * m_viewMatrix * m_modelMatrix;
			m_mvp_dirty = false;
		}
		return m_mvp_matrix;
	}

	void TRRenderer::clearColor(glm::vec4 color)
	{
		m_backBuffer->clear(color);
	}

	int TRRenderer::addPointLight(glm::vec3 pos, glm::vec3 atten, glm::vec3 color)
	{
		return TRShadingPipeline::addPointLight(pos, atten, color);
	}

	TRPointLight &TRRenderer::getPointLight(const int &index)
	{
		return TRShadingPipeline::getPointLight(index);
	}

	void TRRenderer::renderAllDrawableMeshes()
	{
		if (m_shader_handler == nullptr)
		{
			m_shader_handler = std::make_shared<TRDefaultShadingPipeline>();
		}
		
		//Load the matrices
		m_shader_handler->setModelMatrix(m_modelMatrix);
		m_shader_handler->setViewProjectMatrix(m_projectMatrix * m_viewMatrix);

		//Draw a mesh step by step
		m_clip_cull_profile.m_num_cliped_triangles = 0;
		m_clip_cull_profile.m_num_culled_triangles = 0;
		std::vector<TRShadingPipeline::VertexData> rasterized_points;
		rasterized_points.reserve(m_backBuffer->getWidth() * m_backBuffer->getHeight());
		for (size_t m = 0; m < m_drawableMeshes.size(); ++m)
		{
			if (m == skyMesh_index) {
				m_shader_handler->setViewProjectMatrix(m_projectMatrix * m_skyviewMatrix);
			}
			//Configuration
			TRPolygonMode polygonMode = m_drawableMeshes[m]->getPolygonMode();
			TRCullFaceMode cullfaceMode = m_drawableMeshes[m]->getCullfaceMode();
			TRDepthTestMode depthtestMode = m_drawableMeshes[m]->getDepthtestMode();
			TRDepthWriteMode depthwriteMode = m_drawableMeshes[m]->getDepthwriteMode();
			m_shader_handler->setModelMatrix(m_drawableMeshes[m]->getModelMatrix());
			m_shader_handler->setLightingEnable(m_drawableMeshes[m]->getLightingMode() == TRLightingMode::TR_LIGHTING_ENABLE);

			const auto& vertices = m_drawableMeshes[m]->getVerticesAttrib();
			const auto& faces = m_drawableMeshes[m]->getMeshFaces();
			for (size_t f = 0; f < faces.size(); ++f)
			{
				//Setup the shading options
				{
					m_shader_handler->setAmbientCoef(faces[f].kA);
					m_shader_handler->setDiffuseCoef(faces[f].kD);
					m_shader_handler->setSpecularCoef(faces[f].kS);
					m_shader_handler->setEmissionColor(faces[f].kE);
					m_shader_handler->setDiffuseTexId(faces[f].diffuseMapTexId);
					m_shader_handler->setSpecularTexId(faces[f].specularMapTexId);
					m_shader_handler->setNormalTexId(faces[f].normalMapTexId);
					m_shader_handler->setGlowTexId(faces[f].glowMapTexId);
					m_shader_handler->setShininess(faces[f].shininess);
					m_shader_handler->setTangent(faces[f].tangent);
					m_shader_handler->setBitangent(faces[f].bitangent);
				}

				//A triangle as primitive
				TRShadingPipeline::VertexData v[3];
				{
					v[0].pos = vertices.vpositions[faces[f].vposIndex[0]];
					v[0].col = glm::vec3(vertices.vcolors[faces[f].vposIndex[0]]);
					v[0].nor = vertices.vnormals[faces[f].vnorIndex[0]];
					v[0].tex = vertices.vtexcoords[faces[f].vtexIndex[0]];

					v[1].pos = vertices.vpositions[faces[f].vposIndex[1]];
					v[1].col = glm::vec3(vertices.vcolors[faces[f].vposIndex[1]]);
					v[1].nor = vertices.vnormals[faces[f].vnorIndex[1]];
					v[1].tex = vertices.vtexcoords[faces[f].vtexIndex[1]];

					v[2].pos = vertices.vpositions[faces[f].vposIndex[2]];
					v[2].col = glm::vec3(vertices.vcolors[faces[f].vposIndex[2]]);
					v[2].nor = vertices.vnormals[faces[f].vnorIndex[2]];
					v[2].tex = vertices.vtexcoords[faces[f].vtexIndex[2]];
				}

				//Vertex shader stage
				std::vector<TRShadingPipeline::VertexData> clipped_vertices;
				{
					//Vertex shader
					{
						m_shader_handler->vertexShader(v[0]);
						m_shader_handler->vertexShader(v[1]);
						m_shader_handler->vertexShader(v[2]);
					}

					//Homogeneous space cliping
					{
						clipped_vertices = clipingSutherlandHodgeman(v[0], v[1], v[2]);
						if (clipped_vertices.empty())
						{
							++m_clip_cull_profile.m_num_cliped_triangles;
							continue;
						}
					}
					

					// change this in order to fit sky box
					// 
					// 
					// 
					//Perspective division
					for (auto &vert : clipped_vertices)
					{
						//From clip space -> ndc space
						TRShadingPipeline::VertexData::prePerspCorrection(vert);
						vert.cpos /= vert.cpos.w;
						if (m == this->skyMesh_index) {
							vert.cpos.z = 0.99999f;
						}
					}
				}

				int num_verts = clipped_vertices.size();
				for (int i = 0; i < num_verts - 2; ++i)
				{
					//Triangle assembly
					TRShadingPipeline::VertexData vert[3] = {
							clipped_vertices[0],
							clipped_vertices[i + 1],
							clipped_vertices[i + 2] };


					//Rasterization stage
					{
						//Transform to screen space & Rasterization
						{
							vert[0].spos = glm::ivec2(m_viewportMatrix * vert[0].cpos + glm::vec4(0.5f));
							vert[1].spos = glm::ivec2(m_viewportMatrix * vert[1].cpos + glm::vec4(0.5f));
							vert[2].spos = glm::ivec2(m_viewportMatrix * vert[2].cpos + glm::vec4(0.5f));


							//Backface culling
							if (isBackFacing(vert[0].spos, vert[1].spos, vert[2].spos, cullfaceMode))
							{
								++m_clip_cull_profile.m_num_culled_triangles;
								continue;
							}

							switch (polygonMode)
							{
								case TRPolygonMode::TR_TRIANGLE_FILL:
									m_shader_handler->rasterize_fill_edge_function(vert[0], vert[1], vert[2],
										m_backBuffer->getWidth(), m_backBuffer->getHeight(), rasterized_points);
									break;
								case TRPolygonMode::TR_TRIANGLE_WIRE:
									m_shader_handler->rasterize_wire(vert[0], vert[1], vert[2],
										m_backBuffer->getWidth(), m_backBuffer->getHeight(), rasterized_points);
									break;
							}
						}
					}

					if (rasterized_points.empty())
					{
						++m_clip_cull_profile.m_num_culled_triangles;
					}

					//Fragment shader & Depth testing
					for (auto &point : rasterized_points)
					{
						//Perspective correction after rasterization
						TRShadingPipeline::VertexData::aftPrespCorrection(point);
						if (depthtestMode == TRDepthTestMode::TR_DEPTH_TEST_ENABLE &&
							m_backBuffer->readDepth(point.spos.x, point.spos.y) > point.cpos.z)
						{
							glm::vec4 fragColor;
							m_shader_handler->fragmentShader(point, fragColor);
							m_backBuffer->writeColor(point.spos.x, point.spos.y, fragColor);
							if (depthwriteMode == TRDepthWriteMode::TR_DEPTH_WRITE_ENABLE)
							{
								m_backBuffer->writeDepth(point.spos.x, point.spos.y, point.cpos.z);
							}
						}
					}

					rasterized_points.clear();
				}
			}


			m_shader_handler->setViewProjectMatrix(m_projectMatrix* m_viewMatrix);
		}

		//Swap double buffers
		{
			std::swap(m_backBuffer, m_frontBuffer);
		}
		
	}

	unsigned char* TRRenderer::commitRenderedColorBuffer()
	{
		return m_frontBuffer->getColorBuffer();
	}

	unsigned int TRRenderer::getNumberOfClipFaces() const
	{
		return m_clip_cull_profile.m_num_cliped_triangles;
	}

	unsigned int TRRenderer::getNumberOfCullFaces() const
	{
		return m_clip_cull_profile.m_num_culled_triangles;
	}

	std::vector<TRShadingPipeline::VertexData> TRRenderer::clipingSutherlandHodgeman(
		const TRShadingPipeline::VertexData &v0,
		const TRShadingPipeline::VertexData &v1,
		const TRShadingPipeline::VertexData &v2) const
	{
		//Clipping in the homogeneous clipping space
		//Refs:
		//https://fabiensanglard.net/polygon_codec/clippingdocument/Clipping.pdf
		//https://fabiensanglard.net/polygon_codec/

		//Optimization: complete outside or complete inside
		//Note: in the following situations, we could return the answer without complicate cliping,
		//      and this optimization should be very important.
		{
			//Totally inside
			if (isPointInsideInClipingFrustum(v0.cpos)
				&& isPointInsideInClipingFrustum(v1.cpos)
				&& isPointInsideInClipingFrustum(v2.cpos))
			{
				return { v0,v1,v2 };
			}
			//Totally outside
			if (v0.cpos.w < m_frustum_near_far.x && v1.cpos.w < m_frustum_near_far.x && v2.cpos.w < m_frustum_near_far.x)
				return{};
			if (v0.cpos.w > m_frustum_near_far.y && v1.cpos.w > m_frustum_near_far.y && v2.cpos.w > m_frustum_near_far.y)
				return{};
			if (v0.cpos.x > v0.cpos.w && v1.cpos.x > v1.cpos.w && v2.cpos.x > v2.cpos.w)
				return{};
			if (v0.cpos.x <-v0.cpos.w && v1.cpos.x <-v1.cpos.w && v2.cpos.x <-v2.cpos.w)
				return{};
			if (v0.cpos.y > v0.cpos.w && v1.cpos.y > v1.cpos.w && v2.cpos.y > v2.cpos.w)
				return{};
			if (v0.cpos.y <-v0.cpos.w && v1.cpos.y <-v1.cpos.w && v2.cpos.y <-v2.cpos.w)
				return{};
			if (v0.cpos.z > v0.cpos.w && v1.cpos.z > v1.cpos.w && v2.cpos.z > v2.cpos.w)
				return{};
			if (v0.cpos.z <-v0.cpos.w && v1.cpos.z <-v1.cpos.w && v2.cpos.z <-v2.cpos.w)
				return{};
		}

		std::vector<TRShadingPipeline::VertexData> inside_vertices;
		std::vector<TRShadingPipeline::VertexData> tmp = { v0, v1, v2 };
		enum Axis { X = 0, Y = 1, Z = 2};

		//w=x plane & w=-x plane
		{
			inside_vertices = clipingSutherlandHodgeman_aux(tmp, Axis::X, +1);
			tmp = inside_vertices;

			inside_vertices = clipingSutherlandHodgeman_aux(tmp, Axis::X, -1);
			tmp = inside_vertices;
		}

		//w=y plane & w=-y plane
		{
			inside_vertices = clipingSutherlandHodgeman_aux(tmp, Axis::Y, +1);
			tmp = inside_vertices;

			inside_vertices = clipingSutherlandHodgeman_aux(tmp, Axis::Y, -1);
			tmp = inside_vertices;
		}

		//w=z plane & w=-z plane
		{
			inside_vertices = clipingSutherlandHodgeman_aux(tmp, Axis::Z, +1);
			tmp = inside_vertices;

			inside_vertices = clipingSutherlandHodgeman_aux(tmp, Axis::Z, -1);
			tmp = inside_vertices;
		}

		//w=1e-5 plane
		{
			inside_vertices = {};
			int num_verts = tmp.size();
			constexpr float w_clipping_plane = 1e-5;
			for (int i = 0; i < num_verts; ++i)
			{
				const auto &beg_vert = tmp[(i - 1 + num_verts) % num_verts];
				const auto &end_vert = tmp[i];
				float beg_is_inside = (beg_vert.cpos.w < w_clipping_plane) ? -1 : 1;
				float end_is_inside = (end_vert.cpos.w < w_clipping_plane) ? -1 : 1;
				//One of them is outside
				if (beg_is_inside * end_is_inside < 0)
				{
					// t = (w_clipping_plane-w1)/((w1-w2)
					float t = (w_clipping_plane - beg_vert.cpos.w) / (beg_vert.cpos.w - end_vert.cpos.w);
					auto intersected_vert = TRShadingPipeline::VertexData::lerp(beg_vert, end_vert, t);
					inside_vertices.push_back(intersected_vert);
				}
				//If current vertices is inside
				if (end_is_inside > 0)
				{
					inside_vertices.push_back(end_vert);
				}
			}
		}
		
		return inside_vertices;
	}

	std::vector<TRShadingPipeline::VertexData> TRRenderer::clipingSutherlandHodgeman_aux(
		const std::vector<TRShadingPipeline::VertexData> &polygon,
		const int &axis,
		const int &side) const
	{
		std::vector<TRShadingPipeline::VertexData> inside_polygon;

		int num_verts = polygon.size();
		for (int i = 0; i < num_verts; ++i)
		{
			const auto &beg_vert = polygon[(i - 1 + num_verts) % num_verts];
			const auto &end_vert = polygon[i];
			char beg_is_inside = ((side * (beg_vert.cpos[axis]) <= beg_vert.cpos.w) ? 1 : -1);
			char end_is_inside = ((side * (end_vert.cpos[axis]) <= end_vert.cpos.w) ? 1 : -1);
			//One of them is outside
			if (beg_is_inside * end_is_inside < 0)
			{
				// t = (w1 - y1)/((w1-y1)-(w2-y2))
				float t = (beg_vert.cpos.w - side * beg_vert.cpos[axis])
					/ ((beg_vert.cpos.w - side * beg_vert.cpos[axis]) - (end_vert.cpos.w - side * end_vert.cpos[axis]));
				auto intersected_vert = TRShadingPipeline::VertexData::lerp(beg_vert, end_vert, t);
				inside_polygon.push_back(intersected_vert);
			}
			//If current vertices is inside
			if (end_is_inside > 0)
			{
				inside_polygon.push_back(end_vert);
			}
		}
		return inside_polygon;
	}

	bool TRRenderer::isBackFacing(const glm::ivec2 &v0, const glm::ivec2 &v1, const glm::ivec2 &v2, TRCullFaceMode mode) const
	{
		if (mode == TRCullFaceMode::TR_CULL_DISABLE)
			return false;

		auto e1 = v1 - v0;
		auto e2 = v2 - v0;

		int orient = e1.x * e2.y - e1.y * e2.x;

		return (mode == TRCullFaceMode::TR_CULL_BACK) ? (orient > 0) : (orient < 0);
	}

}
