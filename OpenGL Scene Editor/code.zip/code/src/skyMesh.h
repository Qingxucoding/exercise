#ifndef SKYMESH_H
#define SKYMESH_H

#include <vector>
#include <memory>
#include <string>
#include "stb_image.h"
#include "glm/glm.hpp"
#include <iostream>
#include "TRShadingState.h"
#include "TRDrawableMesh.h"
#include <cstring>


namespace TinyRenderer
{
	class SkyMesh : public TRDrawableMesh
	{
	public:
		typedef std::shared_ptr<SkyMesh> ptr;

		glm::mat4 ViewMatrix;
		glm::mat4 projectionMatrix;

		SkyMesh(const std::string& skyPath){
			loadMeshFromFile(skyPath);
		}

	};
};

#endif
