// TerrainGenerator.h
#ifndef TERRAINGENERATOR_H
#define TERRAINGENERATOR_H
#include "stb_image.h"
#include <string>
#include <vector>
#include <glm/glm.hpp>
#include <GL/glew.h>
#include <iostream> 
class TerrainGenerator {
public:
    // 构造函数
    TerrainGenerator(const std::string& imagePath, int width, int height)
        : imgWidth(width), imgHeight(height) {
        loadGrayscaleImage(imagePath, imageData, imgWidth, imgHeight);
        createVertices(imageData, imgWidth, imgHeight);
        createIndices(imgWidth, imgHeight);
        createUVs(imgWidth, imgHeight);
        createNormals(imgWidth, imgHeight);
    }

    // 生成地形数据
    void generateTerrain() {
        // 这个方法可以被用来在需要的时候重新生成地形数据
        // 例如，在修改了图像路径或尺寸后
        createVertices(imageData, imgWidth, imgHeight);
        createIndices(imgWidth, imgHeight);
        createUVs(imgWidth, imgHeight);
        createNormals(imgWidth, imgHeight);
    }

    // 加载灰度图并转换为地形数据
    bool loadGrayscaleImage(const std::string& imagePath, std::vector<unsigned char>& imageData, int& width, int& height) {
        int channels;
        unsigned char* data = stbi_load(imagePath.c_str(), &width, &height, &channels, 0);
        if (!data) {
            std::cerr << "Failed to load image: " << imagePath << std::endl;
            return false;
        }
        imageData.assign(data, data + width * height * channels);
        stbi_image_free(data);
        return true;
    }

    //创建顶点数据和创建索引数据
    void TerrainGenerator::createVertices(const std::vector<unsigned char>& imageData, int width, int height) {
        vertices.resize(width * height * 3); // 每个顶点包含3个GLfloat (X, Y, Z)
        for (int i = 0; i < height; ++i) {
            for (int j = 0; j < width; ++j) {
                int idx = i * width + j;
                float x = (j - width / 2.0f) * 2.0f / (width - 1); // 映射到[-1, 1]范围
                float z = (i - height / 2.0f) * 2.0f / (height - 1); // 映射到[-1, 1]范围
                float y = imageData[idx] / 255.0f; // 灰度值转换为高度

                vertices[idx * 3 + 0] = x; // X坐标
                vertices[idx * 3 + 1] = y; // Y坐标（高度）
                vertices[idx * 3 + 2] = z; // Z坐标
            }
        }
    }
    void TerrainGenerator::createIndices(int width, int height) {
        indices.resize((width - 1) * (height - 1) * 6); // 每个四边形由两个三角形组成，每个三角形3个索引
        for (int i = 0; i < height - 1; ++i) {
            for (int j = 0; j < width - 1; ++j) {
                int baseIdx = i * width + j;
                indices[(baseIdx * 6) + 0] = baseIdx;
                indices[(baseIdx * 6) + 1] = baseIdx + 1;
                indices[(baseIdx * 6) + 2] = baseIdx + width;
                indices[(baseIdx * 6) + 3] = baseIdx + width + 1;
                indices[(baseIdx * 6) + 4] = baseIdx + width;
                indices[(baseIdx * 6) + 5] = baseIdx + width + 1;
            }
        }
    }
    //创建纹理坐标数据
    void TerrainGenerator::createUVs(int width, int height) {
        uvs.resize(width * height * 2); // 每个顶点需要2个GLfloat作为纹理坐标 (U, V)
        for (int i = 0; i < height; ++i) {
            for (int j = 0; j < width; ++j) {
                int idx = i * width + j;
                // 纹理坐标 (U, V) 映射到 [0, 1] 范围内
                uvs[idx * 2 + 0] = (float)j / (width - 1); // U 纹理坐标
                uvs[idx * 2 + 1] = (float)i / (height - 1); // V 纹理坐标
            }
        }
    }
    //创建法线数据
    void TerrainGenerator::createNormals(int width, int height) {
        normals.resize(width * height * 3); // 每个顶点需要3个GLfloat作为法线向量 (X, Y, Z)
        for (int i = 0; i < height - 1; ++i) {
            for (int j = 0; j < width - 1; ++j) {
                // 计算相邻顶点的索引
                int topLeft = i * width + j;
                int topRight = topLeft + 1;
                int bottomLeft = topLeft + width;
                int bottomRight = bottomLeft + 1;

                // 获取顶点位置
                glm::vec3 p1(vertices[topLeft * 3], vertices[topLeft * 3 + 1], vertices[topLeft * 3 + 2]);
                glm::vec3 p2(vertices[topRight * 3], vertices[topRight * 3 + 1], vertices[topRight * 3 + 2]);
                glm::vec3 p3(vertices[bottomLeft * 3], vertices[bottomLeft * 3 + 1], vertices[bottomLeft * 3 + 2]);

                // 计算面法线
                glm::vec3 edge1 = p2 - p1;
                glm::vec3 edge2 = p3 - p1;
                glm::vec3 normal = glm::normalize(glm::cross(edge1, edge2));

                // 累加法线到相邻顶点
                for (int k = 0; k < 3; ++k) {
                    normals[topLeft * 3 + k] += normal[k];
                    normals[topRight * 3 + k] += normal[k];
                    normals[bottomLeft * 3 + k] += normal[k];
                    normals[bottomRight * 3 + k] += normal[k];
                }
            }
        }
        // 归一化法线向量
        for (int i = 0; i < normals.size(); i += 3) {
            glm::vec3 norm(normals[i], normals[i + 1], normals[i + 2]);
            normals[i] = norm.x;
            normals[i + 1] = norm.y;
            normals[i + 2] = norm.z;
        }
    }
    // 获取地形数据的方法
    std::vector<GLfloat> getVertices() const { return vertices; }
    std::vector<unsigned int> getIndices() const { return indices; }
    std::vector<GLfloat> getUVs() const { return uvs; }
    std::vector<GLfloat> getNormals() const { return normals; }

    // 存储地形数据的成员变量
    std::vector<GLfloat> vertices;
    std::vector<unsigned int> indices;
    std::vector<GLfloat> uvs;
    std::vector<GLfloat> normals;

    // 图像尺寸
    int imgWidth;
    int imgHeight;
    std::vector<unsigned char> imageData;
};

#endif // TERRAINGENERATOR_H