﻿/*The MIT License (MIT)

Copyright (c) 2021-Present, Wencong Yang (yangwc3@mail2.sysu.edu.cn).

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.*/


#include "glm/glm.hpp"
#include "glm/gtc/matrix_transform.hpp"
#include<iostream>
#include "TRWindowsApp.h"
#include "TRRenderer.h"
#include "TRUtils.h"
#include <iostream>
#include "mapMesh.h"//加载,渲染地形
#include "skyMesh.h"//天空盒
using namespace TinyRenderer;

void print_vec(const glm::vec4& v) {
	std::cout << "(" << v.x << ", " << v.y << ", " << v.z << ", " << v.w << ")" << std::endl;
}

void print_mat4(glm::mat4 m) {
	for (int i = 0; i < 4; i++)
	{
		for (int j = 0; j < 4; j++)
		{
			std::cout << m[i][j] << " ";
		}
		std::cout << std::endl;
	}
}
std::string wstring_to_string(const std::wstring& wstr) {
	std::string str;

	for (wchar_t wc : wstr) {
		if (wc <= 0x7F) {  // 确保字符在 ASCII 范围内
			str += static_cast<char>(wc);
		}
		else {
			// 如果遇到非 ASCII 字符，可以选择抛出异常或忽略
			std::cerr << "警告: 遇到非 ASCII 字符，跳过转换" << std::endl;
		}
	}

	return str;
}

int main(int argc, char* args[])
{
	//初始化窗口实例
	constexpr int width = 666;
	constexpr int height = 500;
	CoInitializeEx(NULL, COINIT_APARTMENTTHREADED | COINIT_DISABLE_OLE1DDE);
	TRWindowsApp::ptr winApp = TRWindowsApp::getInstance(width, height, "final");

	if (winApp == nullptr)
	{
		return -1;
	}
	//渲染器
	TRRenderer::ptr renderer = std::make_shared<TRRenderer>(width, height);

	//camera
	glm::vec3 cameraPos = glm::vec3(0.8f, 0.0f, 3.7f);
	glm::vec3 lookAtTarget = glm::vec3(0.0f);
	//计算视图矩阵和投影矩阵
	renderer->setViewMatrix(cameraPos, lookAtTarget, glm::vec3(0.0, 1.0, 0.0f));
	renderer->setProjectMatrix(TRUtils::calcPerspProjectMatrix(45.0f, static_cast<float>(width) / height, 0.001f, 100.0f), 0.001f, 100.0f);

	//Load the rendering data

	TRDrawableMesh::ptr man = std::make_shared<TRDrawableMesh>("model/man/man.obj");
	TRDrawableMesh::ptr sunlightmesh = std::make_shared<TRDrawableMesh>("model/light_blue.obj");
	renderer->addRoleMesh(man);
	renderer->addDrawableMesh({sunlightmesh });
	sunlightmesh->setLightingMode(TRLightingMode::TR_LIGHTING_DISABLE);


	//MapMesh::ptr mapMesh = std::make_shared<MapMesh>("model/terrain_small.png", "model/stone.png");//地形
	MapMesh::ptr mapMesh = std::make_shared<MapMesh>("model/terrain.png");//地形
	renderer->addMapMesh(mapMesh);


	SkyMesh::ptr groundMesh = std::make_shared<SkyMesh>("model/sky/floor.obj");
	renderer->addSkyMesh(groundMesh);
	{
		glm::mat4 ground_mesh_model_mat = glm::mat4(1.0f);
		ground_mesh_model_mat = glm::scale(ground_mesh_model_mat, glm::vec3(20.0f, 20.0f, 20.0f));
		groundMesh->setModelMatrix(ground_mesh_model_mat);
	}


	winApp->readyToStart();
	renderer->setShaderPipeline(std::make_shared<TRPhongShadingPipeline>());
	//Point light sources
	glm::vec3 redLightPos = glm::vec3(0.0f, -0.05f, 1.2f);
	glm::vec3 greenLightPos = glm::vec3(0.87f, -0.05f, -0.87f);
	glm::vec3 blueLightPos = glm::vec3(-0.83f, -0.05f, -0.83f);
	int redLightIndex = renderer->addPointLight(redLightPos, glm::vec3(1.0, 0.7, 1.8), glm::vec3(1.9f, 0.0f, 0.0f));
	int greenLightIndex = renderer->addPointLight(greenLightPos, glm::vec3(1.0, 0.7, 1.8), glm::vec3(0.0f, 1.9f, 0.0f));
	auto& redLight = renderer->getPointLight(redLightIndex);
	auto& greenLight = renderer->getPointLight(greenLightIndex);
	glm::vec3 sunLightPos = glm::vec3(0.0f, 30.0f, 0.0f);
	int sunLightIndex = renderer->addPointLight(sunLightPos, glm::vec3(1.0, 0.7, 1.8), glm::vec3(5000.0f, 5000.0f, 5000.0f));
	auto& sunLight = renderer->getPointLight(sunLightIndex);
	glm::mat4 sunlightModelMat = glm::translate(glm::mat4(1.0f), sunLightPos);
	sunlightmesh->setModelMatrix(sunlightModelMat);


	static glm::mat4 model_mat = glm::mat4(1.0f);
	model_mat = glm::rotate(model_mat, 30.0f, glm::vec3(0, 1, 0));
	renderer->setModelMatrix(model_mat);
	bool have_model_loaded = false;
	std::string path;
	//Rendering loop
	while (!winApp->shouldWindowClose())
	{
		////处理各种输入事件
		winApp->processEvent();

		//Clear frame buffer (both color buffer and depth buffer)
		renderer->clearColor(glm::vec4(0.0f, 0.0f, 0.0f, 1.0f));

		//渲染网格
		renderer->setViewerPos(cameraPos);
		renderer->renderAllDrawableMeshes();

		//Display to screen
		double deltaTime = winApp->updateScreenSurface(
			renderer->commitRenderedColorBuffer(),
			width,
			height,
			4,
			renderer->getNumberOfClipFaces(),
			renderer->getNumberOfCullFaces());
		//Camera operation
		{
			//Camera rotation
			//左键-移动模型
			if (winApp->getIsMouseLeftButtonPressed() && !have_model_loaded)
			{
				int deltaX = winApp->getMouseMotionDeltaX();
				int deltaY = winApp->getMouseMotionDeltaY();
				glm::vec3 move_vec = glm::vec3(deltaX, -deltaY, 0.0f);
				renderer->clickEasyModel(winApp->getMouseX(), winApp->getMouseY(), true);
				glm::vec4 target_pos = renderer->clickMapPoint(winApp->getMouseX(), winApp->getMouseY(), true);
				if (renderer->clicked_model_index != -1 && target_pos.w != 0) {
					std::cout << "clicked" << renderer->clicked_model_index << std::endl;
					//target_pos = renderer->m_map_mesh->getModelMatrix() * target_pos;
					print_vec(target_pos);
					glm::vec4 feet_mpos = renderer->m_drawableMeshes[renderer->clicked_model_index]->feet_mpos;
					feet_mpos = renderer->m_drawableMeshes[renderer->clicked_model_index]->getModelMatrix() * feet_mpos;
					glm::vec3 movedir = glm::vec3(target_pos - feet_mpos);
					glm::mat4 move_mat = glm::translate(glm::mat4(1.0f), movedir);
					glm::mat4 src_mat = renderer->m_drawableMeshes[renderer->clicked_model_index]->getModelMatrix();
					renderer->m_drawableMeshes[renderer->clicked_model_index]->setModelMatrix(move_mat * src_mat);
				}
				//else if (renderer->clicked_model_index != -1){
				//	glm::mat4 now_model_mat = renderer->m_drawableMeshes[renderer->clicked_model_index]->getModelMatrix();
				//	renderer->m_drawableMeshes[renderer->clicked_model_index]->setModelMatrix(glm::translate(now_model_mat, move_vec * 0.003f));
				//}
			}
			else if (winApp->getIsMouseLeftButtonPressed() && have_model_loaded) {
				glm::vec4 target_pos = renderer->clickMapPoint(winApp->getMouseX(), winApp->getMouseY(), true);
				std::cout << "hello" << std::endl;
				if (target_pos.w != 0) {
					std::cout << "clicked and put" << std::endl;
					TRDrawableMesh::ptr newMesh = std::make_shared<TRDrawableMesh>(path);
					renderer->addDrawableMesh(newMesh);
					int index = renderer->m_drawableMeshes.size() - 1;
					glm::vec4 feet_mpos = newMesh->feet_mpos;
					feet_mpos = renderer->m_drawableMeshes[index]->getModelMatrix() * feet_mpos;
					glm::vec3 movedir = glm::vec3(target_pos - feet_mpos);
					glm::mat4 move_mat = glm::translate(glm::mat4(1.0f), movedir);
					glm::mat4 src_mat = renderer->m_drawableMeshes[index]->getModelMatrix();
					renderer->m_drawableMeshes[index]->setModelMatrix(move_mat * src_mat);
					have_model_loaded = false;
				}
			}
			else renderer->clickEasyModel(winApp->getMouseX(), winApp->getMouseY(), false);

			//右键-旋转摄像机
			if (winApp->getMouseRightButtonPressed())
			{
				int deltaX = winApp->getMouseMotionDeltaX();
				int deltaY = winApp->getMouseMotionDeltaY();
				glm::mat4 cameraRotMat(1.0f);
				if (std::abs(deltaX) > std::abs(deltaY))
					cameraRotMat = glm::rotate(glm::mat4(1.0f), -deltaX * 0.001f, glm::vec3(0, 1, 0));
				else
					cameraRotMat = glm::rotate(glm::mat4(1.0f), -deltaY * 0.001f, glm::vec3(1, 0, 0));

				cameraPos = glm::vec3(cameraRotMat * glm::vec4(cameraPos, 1.0f));
				renderer->setViewMatrix(cameraPos, lookAtTarget, glm::vec3(0.0, 1.0, 0.0f));
			}


			if (winApp->getFCliked())
			{
				path = wstring_to_string(winApp->ShowFileOpenDialog(NULL));
				have_model_loaded = true;

			}

			//Camera zoom in and zoom out
			//滚轮-缩放
			if (winApp->getMouseWheelDelta() != 0 || winApp->moved_camera())
			{
				glm::vec3 dir = glm::normalize(cameraPos - lookAtTarget);
				glm::vec3 cross_dir = glm::normalize(glm::cross(dir, glm::vec3(0, 1, 0)));
				float dist = glm::length(cameraPos - lookAtTarget);
				glm::vec3 newPos = cameraPos + (winApp->getMouseWheelDelta() * 0.1f) * dir;
				if (glm::length(newPos - lookAtTarget) > 1.0f)
				{
					cameraPos = newPos;
					renderer->setViewMatrix(cameraPos, lookAtTarget, glm::vec3(0.0, 1.0, 0.0f));
				}
			}


			{
				// 角色移动方向
				glm::vec3 movementDirection(0.0f);
				// 检测 WASD 键是否被按下
				if (winApp->getWSClicked()) {
					movementDirection.z -= 0.1f;  // W -> 向前
				}
				if (winApp->getSClicked()) {
					movementDirection.z += 0.1f;  // S -> 向后
				}
				if (winApp->getASClicked()) {
					movementDirection.x -= 0.1f;  // A -> 向左
				}
				if (winApp->getDClicked()) {
					movementDirection.x += 0.1f;  // D -> 向右
				}

				// 更新角色位置
				if (movementDirection != glm::vec3(0.0f)) {
					glm::mat4 moveMatrix = glm::translate(glm::mat4(1.0f), movementDirection);
					glm::mat4 newModelMatrix = renderer->m_drawableMeshes[0]->getModelMatrix() * moveMatrix;
					renderer->m_drawableMeshes[0]->setModelMatrix(newModelMatrix);  // 更新 Diablo 模型的矩阵
				}

				// 保持摄像机和角色的相对位置
				glm::vec3 modelPos = glm::vec3(renderer->m_role_mesh->getModelMatrix()[3]);
				renderer->setViewMatrix(cameraPos, modelPos, glm::vec3(0.0, 1.0, 0.0f));
				//renderer->setViewMatrix(TRUtils::calcViewMatrix(cameraPos, modelPos, glm::vec3(0.0, 1.0, 0.0f)));
			}



			// 角色位置修正
			{
				glm::vec4 feet_mpos = renderer->m_role_mesh->feet_mpos;
				feet_mpos = renderer->m_role_mesh->getModelMatrix() * feet_mpos;
				glm::vec4 target_mpos = glm::inverse(renderer->m_map_mesh->getModelMatrix()) * feet_mpos;
				target_mpos.y = renderer->m_map_mesh->read_map(target_mpos.x + 0.5f, target_mpos.z + 0.5f);
				target_mpos = renderer->m_map_mesh->getModelMatrix() * target_mpos;
				target_mpos.y += 0.1f;

				if (glm::length(target_mpos - feet_mpos) > 0.001f) {
					glm::vec3 move_dir = glm::vec3(target_mpos - feet_mpos) / 6.0f;
					move_dir.y += target_mpos.y / 3;
					glm::mat4 moveMatrix = glm::translate(glm::mat4(1.0f), glm::vec3(target_mpos - feet_mpos) / 6.0f);
					glm::mat4 newModelMatrix = moveMatrix * renderer->m_role_mesh->getModelMatrix();
					renderer->m_drawableMeshes[renderer->roleMesh_index]->setModelMatrix(newModelMatrix);  // 更新 Diablo 模型的矩阵
				}

			}



		}

	}
	renderer->unloadDrawableMesh();
	return 0;
}
