#ifndef TRRENDERER_H
#define TRRENDERER_H

#include "glm/glm.hpp"
#include "SDL2/SDL.h"
#include "TRFrameBuffer.h"
#include "TRDrawableMesh.h"
#include "TRShadingState.h"
#include "TRShadingPipeline.h"
#include "mapMesh.h"
#include "SkyMesh.h"
#include <mutex>

namespace TinyRenderer
{
	class easyModel {
		
	public:
		typedef std::shared_ptr<easyModel> ptr;
		glm::vec4 min_point;
		glm::vec4 max_point;

		easyModel(glm::vec4 center_pos, glm::vec4 max_point)
        {
            this->min_point = center_pos;
			this->max_point = max_point;
        }
		bool in_and_out(glm::vec4 point_one, glm::vec4 point_two, glm::mat4 modelmat) {
			point_one = glm::inverse(modelmat) * point_one;
            point_two = glm::inverse(modelmat) * point_two;
			bool in_or_out1 = (point_one.x >= min_point.x) && (point_one.x <= max_point.x) && (point_one.y >= min_point.y) 
							&& (point_one.y <= max_point.y) && (point_one.z >= min_point.z) && (point_one.z <= max_point.z);
			bool in_or_out2 = (point_two.x >= min_point.x) && (point_two.x <= max_point.x) && (point_two.y >= min_point.y) 
							&& (point_two.y <= max_point.y) && (point_two.z >= min_point.z) && (point_two.z <= max_point.z);
            return in_or_out1 ^ in_or_out2;
		}
		~easyModel() = default;
	};
	class TRRenderer final
	{
	public:
		typedef std::shared_ptr<TRRenderer> ptr;

		TRRenderer(int width, int height);
		~TRRenderer() = default;

		//Drawable objects load/unload
		void addDrawableMesh(TRDrawableMesh::ptr mesh);
		void addDrawableMesh(const std::vector<TRDrawableMesh::ptr> &meshes);
		void unloadDrawableMesh();

		void clearColor(glm::vec4 color);

		//Setting
		//void setViewMatrix(const glm::mat4 &view);
		void setModelMatrix(const glm::mat4 &model);
		void setProjectMatrix(const glm::mat4 &project, float near, float far);
		void setShaderPipeline(TRShadingPipeline::ptr shader);
		void setViewerPos(const glm::vec3 &viewer);

		int addPointLight(glm::vec3 pos, glm::vec3 atten, glm::vec3 color);
		TRPointLight &getPointLight(const int &index);

		glm::mat4 getMVPMatrix();

		//Draw call
		void renderAllDrawableMeshes();

		//Commit rendered result
		unsigned char* commitRenderedColorBuffer();
		unsigned int getNumberOfClipFaces() const;
		unsigned int getNumberOfCullFaces() const;

		// my change 
		void clickEasyModel(int mouse_x, int mouse_y, bool is_click);
		glm::vec4 clickMapPoint(int mouse_x, int mouse_y, bool is_click);
		MapMesh::ptr m_map_mesh;
		SkyMesh::ptr m_sky_mesh;
		TRDrawableMesh::ptr m_role_mesh;
		void setViewMatrix(glm::vec3 camera, glm::vec3 target, glm::vec3 worldUp);

		void addMapMesh(MapMesh::ptr map);
		void addRoleMesh(TRDrawableMesh::ptr role);
		void addSkyMesh(SkyMesh::ptr sky);

		int mapMesh_index = -1;
		int roleMesh_index = -1;
		int skyMesh_index = -1;

		std::vector<easyModel::ptr> easyModels;
		std::vector<std::vector<float>> easy_map;
		int clicked_model_index;
		float clicked_point_x;
        float clicked_point_y;
		float clicked_point_z;

	private:

		//Homogeneous space clipping - Sutherland Hodgeman algorithm
		std::vector<TRShadingPipeline::VertexData> clipingSutherlandHodgeman(
			const TRShadingPipeline::VertexData &v0,
			const TRShadingPipeline::VertexData &v1,
			const TRShadingPipeline::VertexData &v2) const;

		//Cliping auxiliary functions
		std::vector<TRShadingPipeline::VertexData> clipingSutherlandHodgeman_aux(
			const std::vector<TRShadingPipeline::VertexData> &polygon,
			const int &axis, 
			const int &side) const;
		bool isPointInsideInClipingFrustum(const glm::vec4 &p) const
		{
			return (p.x <= p.w && p.x >= -p.w)
				&& (p.y <= p.w && p.y >= -p.w)
				&& (p.z <= p.w && p.z >= -p.w)
				&& (p.w <= m_frustum_near_far.y && p.w >= m_frustum_near_far.x);
		}

		//Back face culling
		bool isBackFacing(const glm::ivec2 &v0, const glm::ivec2 &v1, const glm::ivec2 &v2, TRCullFaceMode mode) const;

	public:

		//Drawable mesh array
		std::vector<TRDrawableMesh::ptr> m_drawableMeshes;

		//MVP transformation matrices
		glm::mat4 m_viewMatrix = glm::mat4(1.0f);
		glm::mat4 m_modelMatrix = glm::mat4(1.0f);
		glm::mat4 m_projectMatrix = glm::mat4(1.0f);
		glm::mat4 m_mvp_matrix = glm::mat4(1.0f);
		bool m_mvp_dirty = false;

		//Near plane & far plane
		glm::vec2 m_frustum_near_far;

		//Viewport transformation (ndc space -> screen space)
		glm::mat4 m_viewportMatrix = glm::mat4(1.0f);
		glm::mat4 m_skyviewMatrix;

		//Shader pipeline handler
		TRShadingPipeline::ptr m_shader_handler = nullptr;

		//Double buffers
		TRFrameBuffer::ptr m_backBuffer;                      // The frame buffer that's going to be written.
		TRFrameBuffer::ptr m_frontBuffer;                     // The frame buffer that's going to be displayed.

		struct Profile
		{
			unsigned int m_num_cliped_triangles = 0;
			unsigned int m_num_culled_triangles = 0;
		};
		Profile m_clip_cull_profile;
	};
}

#endif