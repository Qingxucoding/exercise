```http
src/
├── main/
│   ├── java/com/se/yatspark/
│   │   ├── config/               # 配置类（WebConfig）
│   │   ├── controller/           # API 接口（UserController）
│   │   ├── dto/                  # 数据传输对象（Result）
│   │   ├── entity/               # 数据库实体（User/Appliance）
│   │   ├── interceptors/         # 请求拦截器（LoginInterceptor）
│   │   ├── mapper/               # MyBatis 映射器（UserMapper）
│   │   ├── service/              # 业务逻辑层（UserService）
│   │   ├── utils/                # 工具类（JwtUtil）
│   │   └── YatSparkApplication.java # 启动类
│   └── resources/
│       ├── schema.sql            # 数据库表结构
│       ├── application.yml       # 配置文件
│       └── static/               # 静态资源
```
- **Controller层**：处理HTTP请求，调用Service层
- **Service层**：核心业务逻辑，返回DTO对象
- **Mapper层**：数据库操作接口，与实体类映射
- **Entity类**：与schema.sql表结构一一对应
- **Utils类**：跨层级复用工具类（如JWT生成解析）


## 用户认证模块
### 技术实现
- **鉴权方式**：JWT（无状态认证）
- **密码存储**：明文存储（需后续升级为 BCrypt）
- **权限控制**：基于 ADMIN/USER 角色的拦截器

### 核心接口
| 接口 | 请求类型 | 参数 | 返回值 |
|------|----------|------|--------|
| /user/register | POST | username, password | {"code":200} |
| /user/login    | POST | username, password | {"code":200,"data":token} |

### 关键类说明
- [UserController](src/main/java/com/se/yatspark/controller/UserController.java)：API 入口
- [JwtUtil](src/main/java/com/se/yatspark/utils/JwtUtil.java)：JWT 签发与解析
- [LoginInterceptor](src/main/java/com/se/yatspark/interceptors/LoginInterceptor.java)：登录状态校验
- [User](src/main/java/com/se/yatspark/entity/User.java)：用户实体（含 Role 枚举）

