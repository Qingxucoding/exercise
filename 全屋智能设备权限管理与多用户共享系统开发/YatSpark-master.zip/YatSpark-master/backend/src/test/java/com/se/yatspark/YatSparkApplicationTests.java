package com.se.yatspark;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class YatSparkApplicationTests {

	@Test
	void contextLoads() {
	}

}
