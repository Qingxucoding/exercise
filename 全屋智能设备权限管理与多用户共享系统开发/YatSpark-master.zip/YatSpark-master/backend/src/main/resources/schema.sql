-- 1. 用户表(User)
CREATE TABLE user (
    avatar_url VARCHAR(255),                                                     -- 用户头像地址
    phone VARCHAR(20) PRIMARY KEY,                                               -- 用户唯一标识(电话)
    room_id BIGINT,                                                              -- 用户所属房间ID
    role INT NOT NULL,                                                           -- 用户角色(0:管理员,1:普通用户)
    password VARCHAR(255) NOT NULL,                                              -- 登录密码
    admin_phone VARCHAR(20),                                                     -- 管理员电话
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,                              -- 创建时间
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP   -- 更新时间
    FOREIGN KEY (room_id) REFERENCES room(room_id) ON DELETE SET NULL,           -- 关联房间表
    FOREIGN KEY (admin_phone) REFERENCES user(phone) ON DELETE SET NULL          -- 自关联
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2. 权限表(Permission)
CREATE TABLE permission (

    -- 权限表基本信息
    user_phone VARCHAR(20) PRIMARY KEY,                                          -- 用户电话(主键)
    room_id BIGINT NOT NULL,                                                     -- 所控制的房间ID

    -- 门权限(3项)
    door_open_permission BOOLEAN DEFAULT FALSE,                                  -- 开关门权限
    door_check_permission BOOLEAN DEFAULT FALSE,                                 -- 门日志查看权限
    door_bell_permission BOOLEAN DEFAULT FALSE,                                  -- 门铃权限

    -- 灯权限(3项)
    light_turn_on_permission BOOLEAN DEFAULT FALSE,                              -- 开关灯权限
    light_check_permission BOOLEAN DEFAULT FALSE,                                -- 灯日志查看权限
    light_brightness_permission BOOLEAN DEFAULT FALSE,                           -- 灯亮度权限

    -- 空调权限(5项)
    ac_turn_on_permission BOOLEAN DEFAULT FALSE,                                 -- 开关空调权限
    ac_check_permission BOOLEAN DEFAULT FALSE,                                   -- 空调日志查看权限
    ac_temperature_permission BOOLEAN DEFAULT FALSE,                             -- 空调温度权限
    ac_mode_permission BOOLEAN DEFAULT FALSE,                                    -- 空调模式权限
    ac_speed_permission BOOLEAN DEFAULT FALSE,                                   -- 空调风速权限

    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,                              -- 创建时间
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,  -- 更新时间
    FOREIGN KEY (user_phone) REFERENCES user(phone) ON DELETE CASCADE,           -- 关联用户表
    FOREIGN KEY (room_id) REFERENCES room(room_id) ON DELETE CASCADE             -- 关联房间表

) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. 权限日志表(PermissionLog)
CREATE TABLE permission_log (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,                                        -- 自增主键
    operation_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,                          -- 操作时间
    target_user_phone VARCHAR(20) NOT NULL,                                      -- 被操作用户电话
    operator_phone VARCHAR(20) NOT NULL,                                         -- 操作用户电话
    operation_description TEXT NOT NULL,                                         -- 操作描述
    FOREIGN KEY (target_user_phone) REFERENCES user(phone) ON DELETE CASCADE,    -- 关联用户表
    FOREIGN KEY (operator_phone) REFERENCES user(phone) ON DELETE CASCADE        -- 关联用户表
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4. 房间表(Room)
CREATE TABLE room (
    room_id BIGINT AUTO_INCREMENT PRIMARY KEY,                                   -- 自增主键
    room_number VARCHAR(20),                                                     -- 房间号
    template_id BIGINT NOT NULL,                                                 -- 模板ID
    note VARCHAR(400),                                                           -- 备注信息
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,                              -- 创建时间
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,  -- 更新时间
    FOREIGN KEY (template_id) REFERENCES template(template_id) ON DELETE CASCADE -- 关联模板表
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 5. 模板表(Template)
CREATE TABLE template (
    template_id BIGINT AUTO_INCREMENT PRIMARY KEY,                               -- 自增主键
    template_name VARCHAR(50),                                                   -- 模板名称
    creator_phone VARCHAR(20) NOT NULL,                                          -- 创建者电话
    has_door BOOLEAN DEFAULT FALSE,                                              -- 是否包含门
    has_light BOOLEAN DEFAULT FALSE,                                             -- 是否包含灯
    has_ac BOOLEAN DEFAULT FALSE,                                                -- 是否包含空调
    note VARCHAR(400),                                                           -- 备注信息
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,                              -- 创建时间
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,  -- 更新时间
    FOREIGN KEY (creator_phone) REFERENCES user(phone) ON DELETE CASCADE         -- 关联用户表
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 6. 门锁状态表(DoorStatus)
CREATE TABLE door_status (
    room_id BIGINT PRIMARY KEY,                                                  -- 房间ID(主键)
    is_on BOOLEAN DEFAULT FALSE,                                                 -- 门锁开关状态
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,  -- 更新时间
    FOREIGN KEY (room_id) REFERENCES room(room_id) ON DELETE CASCADE             -- 关联房间表
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 7. 灯状态表(LightStatus)
CREATE TABLE light_status (
    room_id BIGINT PRIMARY KEY,                                                  -- 房间ID(主键)
    is_on BOOLEAN DEFAULT FALSE,                                                 -- 灯开关状态
    brightness INT DEFAULT 80,                                                   -- 亮度值(1-100)
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,  -- 更新时间
    FOREIGN KEY (room_id) REFERENCES room(room_id) ON DELETE CASCADE,            -- 关联房间表
    CHECK (brightness BETWEEN 1 AND 100)                                         -- 亮度范围检查
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 8. 空调状态表(AirConditionerStatus)
CREATE TABLE air_conditioner_status (
    room_id BIGINT PRIMARY KEY,                                                  -- 房间ID(主键)
    is_on BOOLEAN DEFAULT FALSE,                                                 -- 空调开关状态
    temperature INT DEFAULT 25,                                                  -- 设置温度
    mode INT DEFAULT 0,                                                          -- 工作模式(0:制冷,1:制热,2:送风)
    speed INT DEFAULT 0,                                                         -- 风速档位(0:自动,1:低,2:中,3:高)
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,  -- 更新时间
    FOREIGN KEY (room_id) REFERENCES room(room_id) ON DELETE CASCADE,            -- 关联房间表
    CHECK (temperature BETWEEN 16 AND 30)                                        -- 温度范围检查
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 9. 电器日志表(DeviceLog)
CREATE TABLE device_log (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,                                        -- 自增主键
    operation_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,                          -- 操作时间
    room_id BIGINT NOT NULL,                                                     -- 房间号
    user_phone VARCHAR(20) NOT NULL,                                             -- 操作者电话
    device_type VARCHAR(20) NOT NULL,                                            -- 设备类型(门、灯、空调)
    operation_detail TEXT NOT NULL,                                              -- 操作详情
    FOREIGN KEY (room_id) REFERENCES room(room_id) ON DELETE CASCADE,            -- 关联房间表
    FOREIGN KEY (user_phone) REFERENCES user(phone) ON DELETE CASCADE            -- 关联用户表
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
