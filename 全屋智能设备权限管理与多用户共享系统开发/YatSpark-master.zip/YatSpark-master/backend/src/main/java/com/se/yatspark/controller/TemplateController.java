package com.se.yatspark.controller;

import com.se.yatspark.dto.Result;
import com.se.yatspark.entity.Template;
import com.se.yatspark.service.TemplateService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/template")
public class TemplateController {

    @Autowired
    private TemplateService templateService;

    /**
     * 根据ID获取模板
     * @param id 模板ID
     * @return 模板对象
     */
    @GetMapping("/{id}")
    public Result findById(@PathVariable Long id) {
        Template template = templateService.findById(id);
        return template != null ? Result.success(template) : Result.error("模板不存在");
    }

    /**
     * 创建新模板
     * @param template 模板对象
     * @return 操作结果
     */
    @PostMapping
    public Result create(@RequestBody Template template) {
        templateService.create(template);
        return Result.success(null);
    }

    /**
     * 更新模板
     * @param template 模板对象
     * @return 操作结果
     */
    @PutMapping
    public Result update(@RequestBody Template template) {
        templateService.update(template);
        return Result.success(null);
    }

    /**
     * 删除模板
     * @param id 模板ID
     * @return 操作结果
     */
    @DeleteMapping("/{id}")
    public Result delete(@PathVariable Long id) {
        templateService.delete(id);
        return Result.success(null);
    }

    /**
     * 获取所有模板
     * @return 模板列表
     */
    @GetMapping
    public Result findAll() {
        List<Template> templates = templateService.findAll();
        return Result.success(templates);
    }

    /**
     * 根据角色获取模板
     * @param role 角色类型
     * @return 符合条件的模板列表
     */
    @GetMapping("/role/{role}")
    public Result findByRole(@PathVariable Template.Role role) {
        List<Template> templates = templateService.findByRole(role);
        return Result.success(templates);
    }
}
