package com.se.yatspark.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class DeviceLog extends Log {

    /* 房间ID */
    private long room_id;

    /* 操作者ID */
    private String user_phone;

    /* 电器类型 */
    private String device_type;

    /* 操作内容 */
    private String operation_detail;

}
