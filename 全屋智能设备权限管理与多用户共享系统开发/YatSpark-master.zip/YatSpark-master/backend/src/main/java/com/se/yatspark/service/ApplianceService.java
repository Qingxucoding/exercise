package com.se.yatspark.service;

import com.se.yatspark.entity.Appliance;

public interface ApplianceService {
    
}
