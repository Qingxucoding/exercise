package com.se.yatspark.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class AirConditionerPermission extends Permission {

    /* 空调开关权限 */
    private boolean turn_on_permission;

    /* 日志查看权限 */
    private boolean check_permission;

    /* 温度调整权限 */
    private boolean temperature_permission;

    /* 模式调整权限 */
    private boolean mode_permission;

    /* 风速调整权限 */
    private boolean speed_permission;

}
