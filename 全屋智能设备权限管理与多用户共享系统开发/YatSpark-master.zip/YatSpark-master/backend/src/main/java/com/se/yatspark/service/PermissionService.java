package com.se.yatspark.service;

import com.se.yatspark.entity.Permission;
import com.se.yatspark.entity.LightPermission;
import com.se.yatspark.entity.AirConditionerPermission;

import java.util.List;

public interface PermissionService {

    // ========== 基础权限操作 ==========

    /**
     * 根据ID查询权限
     */
    Permission findPermissionById(Long id);

    /**
     * 根据用户ID查询所有权限
     */
    List<Permission> findPermissionsByUserId(Long userId);

    /**
     * 创建新权限
     */
    void createPermission(Permission permission);

    /**
     * 更新权限
     */
    void updatePermission(Permission permission);

    /**
     * 删除权限
     */
    void deletePermission(Long id);

    // ========== 灯具权限操作 ==========

    /**
     * 根据ID查询灯具权限
     */
    LightPermission findLightPermissionById(Long id);

    /**
     * 创建灯具权限
     */
    void createLightPermission(LightPermission lightPermission);

    /**
     * 更新灯具权限
     */
    void updateLightPermission(LightPermission lightPermission);

    // ========== 空调权限操作 ==========

    /**
     * 根据ID查询空调权限
     */
    AirConditionerPermission findAirConditionerPermissionById(Long id);

    /**
     * 创建空调权限
     */
    void createAirConditionerPermission(AirConditionerPermission airConditionerPermission);

    /**
     * 更新空调权限
     */
    void updateAirConditionerPermission(AirConditionerPermission airConditionerPermission);

    // ========== 音响权限操作 ==========

    /**
     * 根据ID查询音响权限
     */
    SpeakerPermission findSpeakerPermissionById(Long id);

    /**
     * 创建音响权限
     */
    void createSpeakerPermission(SpeakerPermission speakerPermission);

    /**
     * 更新音响权限
     */
    void updateSpeakerPermission(SpeakerPermission speakerPermission);
}
