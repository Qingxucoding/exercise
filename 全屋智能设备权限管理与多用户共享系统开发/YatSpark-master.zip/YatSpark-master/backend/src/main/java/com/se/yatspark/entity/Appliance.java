package com.se.yatspark.entity;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class Appliance {

    /* 电器所属房间 */
    private long room_number;

    /* 电器开关状态 */
    private boolean is_on;

    /* 电器更新时间 */
    private LocalDateTime updated_at;

}
