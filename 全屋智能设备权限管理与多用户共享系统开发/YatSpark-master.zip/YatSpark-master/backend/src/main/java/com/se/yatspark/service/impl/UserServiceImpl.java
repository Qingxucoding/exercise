package com.se.yatspark.service.impl;

import com.se.yatspark.entity.User;
import com.se.yatspark.mapper.UserMapper;
import com.se.yatspark.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserMapper userMapper;

    //@Autowired
    //private BCryptPasswordEncoder passwordEncoder; // 自动注

    @Override
    public User fineByUsername(String username) {
        return userMapper.fineByUsername(username);
    }

    @Override
    public void register(String username, String password, User.Role role) {
        //加密
        //String encodedPassword = passwordEncoder.encode(password);
        User user = new User();
        user.setUsername(username);
        user.setPassword(password);
        user.setRole(role);
        userMapper.insert(username, password, role);
    }
}
