package com.se.yatspark.entity;


import lombok.Data;

import java.time.LocalDateTime;

@Data
public class Room {

    /* 房间ID */
    private long room_id;

    /* 房间号码 */
    private String room_number;

    /* 对应模板(房型)ID */
    private long template_id;

    /* 房间对应备注信息 */
    private String note;

    /* 房间创建日期 */
    private LocalDateTime created_at;

    /* 房间更新日期 */
    private LocalDateTime updated_at;

}
