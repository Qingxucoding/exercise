package com.se.yatspark.mapper;


import com.se.yatspark.entity.User;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface UserMapper{
    @Select("SELECT * FROM user WHERE username = #{username}")
    User fineByUsername(String username);

    @Insert("INSERT  INTO user(username, password,  role, created_at, updated_at)" + "values (#{username}, #{password}, #{role}, now(), now()) ")
    void insert(String username, String password,  User.Role role);

}
