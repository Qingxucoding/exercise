package com.se.yatspark.mapper;

import com.se.yatspark.entity.Template;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface TemplateMapper {

    @Select("SELECT * FROM template WHERE id = #{id}")
    Template findById(Long id);

    @Insert("INSERT INTO template(id, role, description, created_by, created_at, updated_at) " +
            "VALUES (#{id}, #{role}, #{description}, #{createdBy}, #{createdAt}, #{updatedAt})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    void insert(Template template);

    @Update("UPDATE template SET " +
            "role = #{role}, " +
            "description = #{description}, " +
            "updated_at = #{updatedAt} " +
            "WHERE id = #{id}")
    void update(Template template);

    @Delete("DELETE FROM template WHERE id = #{id}")
    void delete(Long id);

    @Select("SELECT * FROM template")
    List<Template> findAll();

    // 如果需要根据角色查询
    @Select("SELECT * FROM template WHERE role = #{role}")
    List<Template> findByRole(Template.Role role);
}
