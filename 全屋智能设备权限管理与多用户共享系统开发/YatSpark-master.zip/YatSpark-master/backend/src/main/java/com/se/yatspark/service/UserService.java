package com.se.yatspark.service;


import com.se.yatspark.entity.User;

public interface UserService {

    User fineByUsername(String username);

    void register(String username, String password, User.Role role);
}
