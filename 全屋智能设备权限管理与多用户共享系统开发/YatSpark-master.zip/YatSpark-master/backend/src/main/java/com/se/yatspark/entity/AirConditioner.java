package com.se.yatspark.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class AirConditioner extends Appliance {

    /* 智能空调当前温度状态 */
    private int temperature;

    /* 智能空调当前模式状态(0:制冷,1:制热,2:送风) */
    private int mode;

    /* 智能空调当前风速状态(0:自动,1:低,2:中,3:高) */
    private int speed;

}
