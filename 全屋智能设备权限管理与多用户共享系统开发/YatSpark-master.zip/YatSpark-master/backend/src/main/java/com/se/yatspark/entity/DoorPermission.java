package com.se.yatspark.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class DoorPermission extends Permission {

    /* 门锁开关权限 */
    private boolean turn_on_permission;

    /* 日志查看权限 */
    private boolean check_permission;

    /* 门铃权限 */
    private boolean bell_permission;

}
