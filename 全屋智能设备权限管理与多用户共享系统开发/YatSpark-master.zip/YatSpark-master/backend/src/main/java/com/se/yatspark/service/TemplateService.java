package com.se.yatspark.service;

import com.se.yatspark.entity.Template;
import java.util.List;

public interface TemplateService {

    /**
     * 根据ID获取模板
     * @param id 模板ID
     * @return 模板对象
     */
    Template findById(Long id);

    /**
     * 创建新模板
     * @param template 模板对象
     */
    void create(Template template);

    /**
     * 更新模板
     * @param template 模板对象
     */
    void update(Template template);

    /**
     * 删除模板
     * @param id 模板ID
     */
    void delete(Long id);

    /**
     * 获取所有模板
     * @return 模板列表
     */
    List<Template> findAll();

    /**
     * 根据角色获取模板
     * @param role 角色类型
     * @return 符合条件的模板列表
     */
    List<Template> findByRole(Template.Role role);
}
