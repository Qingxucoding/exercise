package com.se.yatspark.mapper;

import com.se.yatspark.entity.Appliance;
import com.se.yatspark.entity.Light;
import com.se.yatspark.entity.AirConditioner;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface ApplianceMapper {
    
    // ========== 基础电器操作 ==========
    
    @Select("SELECT * FROM appliances")
    List<Appliance> findAllAppliances();
    
    @Select("SELECT * FROM appliances WHERE id = #{id}")
    Appliance findApplianceById(Long id);
    
    @Insert("INSERT INTO appliances (name, type, status) VALUES (#{name}, #{type}, #{status})")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    void insertAppliance(Appliance appliance);
    
    @Update("UPDATE appliances SET status = #{status}, updated_at = NOW() WHERE id = #{id}")
    void updateApplianceStatus(@Param("id") Long id, @Param("status") Appliance.Status status);
    
    @Delete("DELETE FROM appliances WHERE id = #{id}")
    void deleteAppliance(Long id);
    
    // ========== 灯具操作 ==========
    
    @Select("SELECT l.*, a.name, a.type, a.status, a.created_at, a.updated_at " +
            "FROM lights l JOIN appliances a ON l.id = a.id WHERE l.id = #{id}")
    @Results({
        @Result(property = "id", column = "id"),
        @Result(property = "name", column = "name"),
        @Result(property = "type", column = "type"),
        @Result(property = "status", column = "status"),
        @Result(property = "createdAt", column = "created_at"),
        @Result(property = "updatedAt", column = "updated_at"),
        @Result(property = "brightness", column = "brightness"),
        @Result(property = "isOn", column = "is_on")
    })
    Light findLightById(Long id);
    
    @Select("SELECT l.*, a.name, a.type, a.status, a.created_at, a.updated_at " +
            "FROM lights l JOIN appliances a ON l.id = a.id WHERE a.status = 'AVAILABLE'")
    @Results({
        @Result(property = "id", column = "id"),
        @Result(property = "name", column = "name"),
        @Result(property = "type", column = "type"),
        @Result(property = "status", column = "status"),
        @Result(property = "createdAt", column = "created_at"),
        @Result(property = "updatedAt", column = "updated_at"),
        @Result(property = "brightness", column = "brightness"),
        @Result(property = "isOn", column = "is_on")
    })
    List<Light> findAllLights();
    
    @Insert("INSERT INTO lights (id, brightness, is_on) VALUES (#{id}, #{brightness}, #{isOn})")
    void insertLight(Light light);
    
    @Update("UPDATE lights SET brightness = #{brightness}, is_on = #{isOn} WHERE id = #{id}")
    void updateLight(Light light);
    
    // ========== 空调操作 ==========
    
    @Select("SELECT ac.*, a.name, a.type, a.status, a.created_at, a.updated_at " +
            "FROM air_conditioners ac JOIN appliances a ON ac.id = a.id WHERE ac.id = #{id}")
    @Results({
        @Result(property = "id", column = "id"),
        @Result(property = "name", column = "name"),
        @Result(property = "type", column = "type"),
        @Result(property = "status", column = "status"),
        @Result(property = "createdAt", column = "created_at"),
        @Result(property = "updatedAt", column = "updated_at"),
        @Result(property = "temperature", column = "temperature"),
        @Result(property = "mode", column = "mode"),
        @Result(property = "fanSpeed", column = "fan_speed"),
        @Result(property = "isOn", column = "is_on")
    })
    AirConditioner findAirConditionerById(Long id);
    
    @Select("SELECT ac.*, a.name, a.type, a.status, a.created_at, a.updated_at " +
            "FROM air_conditioners ac JOIN appliances a ON ac.id = a.id WHERE a.status = 'AVAILABLE'")
    @Results({
        @Result(property = "id", column = "id"),
        @Result(property = "name", column = "name"),
        @Result(property = "type", column = "type"),
        @Result(property = "status", column = "status"),
        @Result(property = "createdAt", column = "created_at"),
        @Result(property = "updatedAt", column = "updated_at"),
        @Result(property = "temperature", column = "temperature"),
        @Result(property = "mode", column = "mode"),
        @Result(property = "fanSpeed", column = "fan_speed"),
        @Result(property = "isOn", column = "is_on")
    })
    List<AirConditioner> findAllAirConditioners();
    
    @Insert("INSERT INTO air_conditioners (id, temperature, mode, fan_speed, is_on) " +
            "VALUES (#{id}, #{temperature}, #{mode}, #{fanSpeed}, #{isOn})")
    void insertAirConditioner(AirConditioner airConditioner);
    
    @Update("UPDATE air_conditioners SET temperature = #{temperature}, mode = #{mode}, " +
            "fan_speed = #{fanSpeed}, is_on = #{isOn} WHERE id = #{id}")
    void updateAirConditioner(AirConditioner airConditioner);
    
    // ========== 音响操作 ==========
    
    @Select("SELECT s.*, a.name, a.type, a.status, a.created_at, a.updated_at " +
            "FROM speakers s JOIN appliances a ON s.id = a.id WHERE s.id = #{id}")
    @Results({
        @Result(property = "id", column = "id"),
        @Result(property = "name", column = "name"),
        @Result(property = "type", column = "type"),
        @Result(property = "status", column = "status"),
        @Result(property = "createdAt", column = "created_at"),
        @Result(property = "updatedAt", column = "updated_at"),
        @Result(property = "volume", column = "volume"),
        @Result(property = "isOn", column = "is_on"),
        @Result(property = "isPlaying", column = "is_playing"),
        @Result(property = "currentSource", column = "current_source")
    })
    Speaker findSpeakerById(Long id);
    
    @Select("SELECT s.*, a.name, a.type, a.status, a.created_at, a.updated_at " +
            "FROM speakers s JOIN appliances a ON s.id = a.id WHERE a.status = 'AVAILABLE'")
    @Results({
        @Result(property = "id", column = "id"),
        @Result(property = "name", column = "name"),
        @Result(property = "type", column = "type"),
        @Result(property = "status", column = "status"),
        @Result(property = "createdAt", column = "created_at"),
        @Result(property = "updatedAt", column = "updated_at"),
        @Result(property = "volume", column = "volume"),
        @Result(property = "isOn", column = "is_on"),
        @Result(property = "isPlaying", column = "is_playing"),
        @Result(property = "currentSource", column = "current_source")
    })
    List<Speaker> findAllSpeakers();
    
    @Insert("INSERT INTO speakers (id, volume, is_on, is_playing, current_source) " +
            "VALUES (#{id}, #{volume}, #{isOn}, #{isPlaying}, #{currentSource})")
    void insertSpeaker(Speaker speaker);
    
    @Update("UPDATE speakers SET volume = #{volume}, is_on = #{isOn}, is_playing = #{isPlaying}, " +
            "current_source = #{currentSource} WHERE id = #{id}")
    void updateSpeaker(Speaker speaker);
}