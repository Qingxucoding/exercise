package com.se.yatspark.controller;

import com.se.yatspark.dto.Result;
import com.se.yatspark.entity.Permission;
import com.se.yatspark.entity.LightPermission;
import com.se.yatspark.entity.AirConditionerPermission;
import com.se.yatspark.service.PermissionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/permission")
public class PermissionController {

    @Autowired
    private PermissionService permissionService;

    // ========== 基础权限操作 ==========

    @GetMapping("/{id}")
    public Result getPermissionById(@PathVariable Long id) {
        Permission permission = permissionService.findPermissionById(id);
        return Result.success(permission);
    }

    @GetMapping("/user/{userId}")
    public Result getPermissionsByUserId(@PathVariable Long userId) {
        List<Permission> permissions = permissionService.findPermissionsByUserId(userId);
        return Result.success(permissions);
    }

    @PostMapping
    public Result createPermission(@RequestBody Permission permission) {
        permissionService.createPermission(permission);
        return Result.success(null);
    }

    @PutMapping
    public Result updatePermission(@RequestBody Permission permission) {
        permissionService.updatePermission(permission);
        return Result.success(null);
    }

    @DeleteMapping("/{id}")
    public Result deletePermission(@PathVariable Long id) {
        permissionService.deletePermission(id);
        return Result.success(null);
    }

    // ========== 灯具权限操作 ==========

    @GetMapping("/light/{id}")
    public Result getLightPermissionById(@PathVariable Long id) {
        LightPermission lightPermission = permissionService.findLightPermissionById(id);
        return Result.success(lightPermission);
    }

    @PostMapping("/light")
    public Result createLightPermission(@RequestBody LightPermission lightPermission) {
        permissionService.createLightPermission(lightPermission);
        return Result.success(null);
    }

    @PutMapping("/light")
    public Result updateLightPermission(@RequestBody LightPermission lightPermission) {
        permissionService.updateLightPermission(lightPermission);
        return Result.success(null);
    }

    // ========== 空调权限操作 ==========

    @GetMapping("/air-conditioner/{id}")
    public Result getAirConditionerPermissionById(@PathVariable Long id) {
        AirConditionerPermission airConditionerPermission = permissionService.findAirConditionerPermissionById(id);
        return Result.success(airConditionerPermission);
    }

    @PostMapping("/air-conditioner")
    public Result createAirConditionerPermission(@RequestBody AirConditionerPermission airConditionerPermission) {
        permissionService.createAirConditionerPermission(airConditionerPermission);
        return Result.success(null);
    }

    @PutMapping("/air-conditioner")
    public Result updateAirConditionerPermission(@RequestBody AirConditionerPermission airConditionerPermission) {
        permissionService.updateAirConditionerPermission(airConditionerPermission);
        return Result.success(null);
    }

    // ========== 音响权限操作 ==========

    @GetMapping("/speaker/{id}")
    public Result getSpeakerPermissionById(@PathVariable Long id) {
        SpeakerPermission speakerPermission = permissionService.findSpeakerPermissionById(id);
        return Result.success(speakerPermission);
    }

    @PostMapping("/speaker")
    public Result createSpeakerPermission(@RequestBody SpeakerPermission speakerPermission) {
        permissionService.createSpeakerPermission(speakerPermission);
        return Result.success(null);
    }

    @PutMapping("/speaker")
    public Result updateSpeakerPermission(@RequestBody SpeakerPermission speakerPermission) {
        permissionService.updateSpeakerPermission(speakerPermission);
        return Result.success(null);
    }
}
