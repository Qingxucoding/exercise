package com.se.yatspark.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class Door extends Appliance {

    /* 门没有专属的状态，设置空类以保证软件完整性 */

}
