package com.se.yatspark.entity;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class Log {

    /* 日志ID */
    private long id;

    /* 日志生成时间 */
    private LocalDateTime operation_time;

}
