package com.se.yatspark.entity;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class Template {

    /* 模板ID */
    private long template_id;

    /* 模板名称 */
    private String template_name;

    /* 创建者ID */
    private String creator_phone;

    /* 该房型是否含有门 */
    private boolean has_door;

    /* 该房型是否含有灯 */
    private boolean has_light;

    /* 该房型是否含有空调 */
    private boolean has_ac;

    /* 房型对应备注信息 */
    private String note;

    /* 模板创建日期 */
    private LocalDateTime created_at;

    /* 模板更新日期 */
    private LocalDateTime updated_at;

}
