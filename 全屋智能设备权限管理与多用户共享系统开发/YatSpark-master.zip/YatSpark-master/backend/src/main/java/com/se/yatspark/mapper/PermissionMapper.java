package com.se.yatspark.mapper;

import com.se.yatspark.entity.Permission;
import com.se.yatspark.entity.LightPermission;
import com.se.yatspark.entity.AirConditionerPermission;
import org.apache.ibatis.annotations.*;

import java.util.List;

@Mapper
public interface PermissionMapper {

    // ========== 基础权限操作 ==========

    @Select("SELECT * FROM permissions WHERE id = #{id}")
    @Results({
            @Result(property = "id", column = "id"),
            @Result(property = "user", column = "user_id", one = @One(select = "com.se.yatspark.mapper.UserMapper.fineByUsername")),
            @Result(property = "appliancePermission", column = "appliance_permission"),
            @Result(property = "startTime", column = "start_time"),
            @Result(property = "endTime", column = "end_time"),
            @Result(property = "createdAt", column = "created_at"),
            @Result(property = "updatedAt", column = "updated_at")
    })
    Permission findPermissionById(Long id);

    @Select("SELECT * FROM permissions WHERE user_id = #{userId}")
    @Results({
            @Result(property = "id", column = "id"),
            @Result(property = "user", column = "user_id", one = @One(select = "com.se.yatspark.mapper.UserMapper.fineByUsername")),
            @Result(property = "appliancePermission", column = "appliance_permission"),
            @Result(property = "startTime", column = "start_time"),
            @Result(property = "endTime", column = "end_time"),
            @Result(property = "createdAt", column = "created_at"),
            @Result(property = "updatedAt", column = "updated_at")
    })
    List<Permission> findPermissionsByUserId(Long userId);

    @Insert("INSERT INTO permissions (user_id, appliance_permission, start_time, end_time, created_at, updated_at) " +
            "VALUES (#{user.id}, #{appliancePermission}, #{startTime}, #{endTime}, NOW(), NOW())")
    @Options(useGeneratedKeys = true, keyProperty = "id")
    void insertPermission(Permission permission);

    @Update("UPDATE permissions SET appliance_permission = #{appliancePermission}, " +
            "start_time = #{startTime}, end_time = #{endTime}, updated_at = NOW() WHERE id = #{id}")
    void updatePermission(Permission permission);

    @Delete("DELETE FROM permissions WHERE id = #{id}")
    void deletePermission(Long id);

    // ========== 灯具权限操作 ==========

    @Select("SELECT lp.*, p.user_id, p.appliance_permission, p.start_time, p.end_time, p.created_at, p.updated_at " +
            "FROM light_permissions lp JOIN permissions p ON lp.id = p.id WHERE lp.id = #{id}")
    @Results({
            @Result(property = "id", column = "id"),
            @Result(property = "user", column = "user_id", one = @One(select = "com.se.yatspark.mapper.UserMapper.fineByUsername")),
            @Result(property = "appliancePermission", column = "appliance_permission"),
            @Result(property = "startTime", column = "start_time"),
            @Result(property = "endTime", column = "end_time"),
            @Result(property = "createdAt", column = "created_at"),
            @Result(property = "updatedAt", column = "updated_at"),
            @Result(property = "turnOnOff", column = "turn_on_off"),
            @Result(property = "setBrightness", column = "set_brightness"),
            @Result(property = "check", column = "check")
    })
    LightPermission findLightPermissionById(Long id);

    @Insert("INSERT INTO light_permissions (id, turn_on_off, set_brightness, check) " +
            "VALUES (#{id}, #{turnOnOff}, #{setBrightness}, #{check})")
    void insertLightPermission(LightPermission lightPermission);

    @Update("UPDATE light_permissions SET turn_on_off = #{turnOnOff}, " +
            "set_brightness = #{setBrightness}, check = #{check} WHERE id = #{id}")
    void updateLightPermission(LightPermission lightPermission);

    // ========== 空调权限操作 ==========

    @Select("SELECT acp.*, p.user_id, p.appliance_permission, p.start_time, p.end_time, p.created_at, p.updated_at " +
            "FROM air_conditioner_permissions acp JOIN permissions p ON acp.id = p.id WHERE acp.id = #{id}")
    @Results({
            @Result(property = "id", column = "id"),
            @Result(property = "user", column = "user_id", one = @One(select = "com.se.yatspark.mapper.UserMapper.fineByUsername")),
            @Result(property = "appliancePermission", column = "appliance_permission"),
            @Result(property = "startTime", column = "start_time"),
            @Result(property = "endTime", column = "end_time"),
            @Result(property = "createdAt", column = "created_at"),
            @Result(property = "updatedAt", column = "updated_at"),
            @Result(property = "turnOnOff", column = "turn_on_off"),
            @Result(property = "setTemperature", column = "set_temperature"),
            @Result(property = "setMode", column = "set_mode"),
            @Result(property = "setFanSpeed", column = "set_fan_speed"),
            @Result(property = "check", column = "check")
    })
    AirConditionerPermission findAirConditionerPermissionById(Long id);

    @Insert("INSERT INTO air_conditioner_permissions (id, turn_on_off, set_temperature, set_mode, set_fan_speed, check) " +
            "VALUES (#{id}, #{turnOnOff}, #{setTemperature}, #{setMode}, #{setFanSpeed}, #{check})")
    void insertAirConditionerPermission(AirConditionerPermission airConditionerPermission);

    @Update("UPDATE air_conditioner_permissions SET turn_on_off = #{turnOnOff}, set_temperature = #{setTemperature}, " +
            "set_mode = #{setMode}, set_fan_speed = #{setFanSpeed}, check = #{check} WHERE id = #{id}")
    void updateAirConditionerPermission(AirConditionerPermission airConditionerPermission);

    // ========== 音响权限操作 ==========

    @Select("SELECT sp.*, p.user_id, p.appliance_permission, p.start_time, p.end_time, p.created_at, p.updated_at " +
            "FROM speaker_permissions sp JOIN permissions p ON sp.id = p.id WHERE sp.id = #{id}")
    @Results({
            @Result(property = "id", column = "id"),
            @Result(property = "user", column = "user_id", one = @One(select = "com.se.yatspark.mapper.UserMapper.fineByUsername")),
            @Result(property = "appliancePermission", column = "appliance_permission"),
            @Result(property = "startTime", column = "start_time"),
            @Result(property = "endTime", column = "end_time"),
            @Result(property = "createdAt", column = "created_at"),
            @Result(property = "updatedAt", column = "updated_at"),
            @Result(property = "turnOnOff", column = "turn_on_off"),
            @Result(property = "startStopPlay", column = "start_stop_play"),
            @Result(property = "switchSource", column = "switch_source"),
            @Result(property = "setVolume", column = "set_volume"),
            @Result(property = "check", column = "check")
    })
    SpeakerPermission findSpeakerPermissionById(Long id);

    @Insert("INSERT INTO speaker_permissions (id, turn_on_off, start_stop_play, switch_source, set_volume, check) " +
            "VALUES (#{id}, #{turnOnOff}, #{startStopPlay}, #{switchSource}, #{setVolume}, #{check})")
    void insertSpeakerPermission(SpeakerPermission speakerPermission);

    @Update("UPDATE speaker_permissions SET turn_on_off = #{turnOnOff}, start_stop_play = #{startStopPlay}, " +
            "switch_source = #{switchSource}, set_volume = #{setVolume}, check = #{check} WHERE id = #{id}")
    void updateSpeakerPermission(SpeakerPermission speakerPermission);
}
