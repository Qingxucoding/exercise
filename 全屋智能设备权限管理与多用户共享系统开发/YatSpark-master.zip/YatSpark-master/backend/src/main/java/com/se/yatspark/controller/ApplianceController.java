package com.se.yatspark.controller;

public class ApplianceController {
    
}
