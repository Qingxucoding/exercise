package com.se.yatspark.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;

@EqualsAndHashCode(callSuper = true)
@Data
public class Light extends Appliance {

    /* 智能电灯当前亮度状态（1-100） */
    private int brightness;

}
