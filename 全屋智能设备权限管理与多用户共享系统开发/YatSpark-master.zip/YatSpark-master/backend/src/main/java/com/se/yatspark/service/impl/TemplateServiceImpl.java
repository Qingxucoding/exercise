package com.se.yatspark.service.impl;

import com.se.yatspark.entity.Template;
import com.se.yatspark.mapper.TemplateMapper;
import com.se.yatspark.service.TemplateService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TemplateServiceImpl implements TemplateService {

    @Autowired
    private TemplateMapper templateMapper;

    @Override
    public Template findById(Long id) {
        return templateMapper.findById(id);
    }

    @Override
    public void create(Template template) {
        templateMapper.insert(template);
    }

    @Override
    public void update(Template template) {
        templateMapper.update(template);
    }

    @Override
    public void delete(Long id) {
        templateMapper.delete(id);
    }

    @Override
    public List<Template> findAll() {
        return templateMapper.findAll();
    }

    @Override
    public List<Template> findByRole(Template.Role role) {
        return templateMapper.findByRole(role);
    }
}
