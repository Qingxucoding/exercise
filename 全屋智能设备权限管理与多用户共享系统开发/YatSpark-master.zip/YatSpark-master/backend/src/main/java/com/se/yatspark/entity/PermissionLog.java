package com.se.yatspark.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class PermissionLog extends Log {

    /* 被操作者ID */
    private String target_user_phone;

    /* 操作者ID */
    private String operator_phone;

    /* 操作内容 */
    private String operation_description;

}
