package com.se.yatspark.entity;

import lombok.Data;
import lombok.EqualsAndHashCode;

@Data
@EqualsAndHashCode(callSuper = true)
public class LightPermission extends Permission {

    /* 电灯开关权限 */
    private boolean turn_on_permission;

    /* 日志查看权限 */
    private boolean check_permission;

    /* 亮度调整权限 */
    private boolean brightness_permission;

}
