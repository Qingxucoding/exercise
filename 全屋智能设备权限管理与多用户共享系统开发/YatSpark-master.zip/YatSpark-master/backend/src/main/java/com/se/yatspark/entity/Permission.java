package com.se.yatspark.entity;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class Permission {

    /* 个性化权限所对应的用户ID */
    private String user_phone;

    /* 个性化权限所对应的房间号 */
    private long room_number;

    /* 个性化权限创建时间 */
    private LocalDateTime created_at;

    /* 个性化权限调整时间 */
    private LocalDateTime updated_at;

}
