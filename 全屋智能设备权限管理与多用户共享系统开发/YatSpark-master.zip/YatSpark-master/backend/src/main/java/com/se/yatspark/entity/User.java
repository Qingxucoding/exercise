package com.se.yatspark.entity;


import lombok.Data;

import java.time.LocalDateTime;

@Data
public class User {

    /* 用户头像 */
    private String avatar_url;

    /* 用户手机号 */
    private String phone;

    /* 房间ID */
    private long room_id;

    /* 用户角色(0:管理员,1:普通用户) */
    private int role;

    /* 用户密码 */
    private String password;

    /* 所绑定的管理员电话(若本身为管理员则为null) */
    private String admin_phone;

    /* 用户创建日期 */
    private LocalDateTime created_at;

    /* 用户更新日期 */
    private LocalDateTime updated_at;

}
