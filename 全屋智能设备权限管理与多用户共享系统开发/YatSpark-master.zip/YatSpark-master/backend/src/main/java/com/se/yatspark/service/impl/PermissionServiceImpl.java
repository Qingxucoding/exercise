package com.se.yatspark.service.impl;

import com.se.yatspark.entity.Permission;
import com.se.yatspark.entity.LightPermission;
import com.se.yatspark.entity.AirConditionerPermission;
import com.se.yatspark.mapper.PermissionMapper;
import com.se.yatspark.service.PermissionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PermissionServiceImpl implements PermissionService {

    @Autowired
    private PermissionMapper permissionMapper;

    // ========== 基础权限操作 ==========

    @Override
    public Permission findPermissionById(Long id) {
        return permissionMapper.findPermissionById(id);
    }

    @Override
    public List<Permission> findPermissionsByUserId(Long userId) {
        return permissionMapper.findPermissionsByUserId(userId);
    }

    @Override
    public void createPermission(Permission permission) {
        permissionMapper.insertPermission(permission);
    }

    @Override
    public void updatePermission(Permission permission) {
        permissionMapper.updatePermission(permission);
    }

    @Override
    public void deletePermission(Long id) {
        permissionMapper.deletePermission(id);
    }

    // ========== 灯具权限操作 ==========

    @Override
    public LightPermission findLightPermissionById(Long id) {
        return permissionMapper.findLightPermissionById(id);
    }

    @Override
    public void createLightPermission(LightPermission lightPermission) {
        permissionMapper.insertLightPermission(lightPermission);
    }

    @Override
    public void updateLightPermission(LightPermission lightPermission) {
        permissionMapper.updateLightPermission(lightPermission);
    }

    // ========== 空调权限操作 ==========

    @Override
    public AirConditionerPermission findAirConditionerPermissionById(Long id) {
        return permissionMapper.findAirConditionerPermissionById(id);
    }

    @Override
    public void createAirConditionerPermission(AirConditionerPermission airConditionerPermission) {
        permissionMapper.insertAirConditionerPermission(airConditionerPermission);
    }

    @Override
    public void updateAirConditionerPermission(AirConditionerPermission airConditionerPermission) {
        permissionMapper.updateAirConditionerPermission(airConditionerPermission);
    }

    // ========== 音响权限操作 ==========

    @Override
    public SpeakerPermission findSpeakerPermissionById(Long id) {
        return permissionMapper.findSpeakerPermissionById(id);
    }

    @Override
    public void createSpeakerPermission(SpeakerPermission speakerPermission) {
        permissionMapper.insertSpeakerPermission(speakerPermission);
    }

    @Override
    public void updateSpeakerPermission(SpeakerPermission speakerPermission) {
        permissionMapper.updateSpeakerPermission(speakerPermission);
    }
}
