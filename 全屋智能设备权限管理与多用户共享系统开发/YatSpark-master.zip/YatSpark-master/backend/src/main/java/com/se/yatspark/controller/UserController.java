package com.se.yatspark.controller;

import com.se.yatspark.dto.Result;
import com.se.yatspark.entity.User;
import com.se.yatspark.mapper.UserMapper;
import com.se.yatspark.service.UserService;
import com.se.yatspark.utils.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping("/register")
    public Result register(String username, String password, User.Role role) {
        User user = userService.fineByUsername(username);
        if(user == null) {
            userService.register(username, password, role);
            return  Result.success(null);
        } else {
            return Result.error("用户已存在");
        }
    }

    @PostMapping("/login")
    public Result login(String username, String password) {
        User user = userService.fineByUsername(username);
        if(user == null) {
            return Result.error("用户不存在");
        } else {
            if(password.equals(user.getPassword())) {
                Map<String, Object> claims = new HashMap<>();
                claims.put("username", username);
                claims.put("id", user.getId());
                String token = JwtUtil.createToken(claims);
                return Result.success(token);
            } else {
                return Result.error("密码错误");
            }
        }
    }

    @PostMapping("/info")
    public Result info(String username) {
        User user = userService.fineByUsername(username);
        return Result.success(user);
    }
}
